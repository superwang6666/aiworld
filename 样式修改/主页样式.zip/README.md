
  # world主页

  This is a code bundle for world主页. The original project is available at https://www.figma.com/design/b7zYQF1uxEQ21v8h2NTWFQ/world%E4%B8%BB%E9%A1%B5.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  