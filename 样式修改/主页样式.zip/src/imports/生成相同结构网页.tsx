import svgPaths from "./svg-74dinh8lol";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

function Container() {
  return <div className="absolute h-[1017.6px] left-0 top-0 w-[1678.4px]" data-name="Container" style={{ backgroundImage: "linear-gradient(rgba(255, 255, 255, 0.02) 0%, rgba(0, 0, 0, 0) 0%), linear-gradient(90deg, rgba(255, 255, 255, 0.02) 0%, rgba(0, 0, 0, 0) 0%)" }} />;
}

function Text() {
  return (
    <div className="content-stretch flex h-[20px] items-start relative shrink-0 w-full" data-name="Text">
      <p className="css-4hzbpn flex-[1_0_0] font-['Arial:Bold',sans-serif] leading-[24px] min-h-px min-w-px not-italic relative text-[13px] text-white">WORLD</p>
    </div>
  );
}

function Container1() {
  return (
    <div className="bg-gradient-to-r flex-[1_0_0] from-[#8a8a95] h-[36px] min-h-px min-w-px relative rounded-[18px] to-[#6a6a75]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[7.6px] px-[16px] relative size-full">
        <Text />
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="bg-[#2a2a35] h-[23.988px] relative rounded-[18px] shrink-0 w-[60px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[12px] py-[4px] relative size-full">
        <p className="css-4hzbpn flex-[1_0_0] font-['Arial:Regular',sans-serif] leading-[16px] min-h-px min-w-px not-italic relative text-[#c1c5cc] text-[12px]">BETA</p>
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="h-[36px] relative shrink-0 w-[150.5px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Container1 />
        <Text1 />
      </div>
    </div>
  );
}

function Link() {
  return (
    <div className="h-[32px] relative shrink-0 px-3" data-name="Link">
      <div className="flex items-center h-full">
        <p className="css-ew64yg font-['Arial:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] leading-[20px] text-[#c1c5cc] text-[14px]" style={{ fontVariationSettings: "'wght' 400" }}>
          简体中文
        </p>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="h-[20px] overflow-visible relative shrink-0 w-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" viewBox="0 0 24 24">
        <path d="M8.5 11C9.32843 11 10 10.3284 10 9.5C10 8.67157 9.32843 8 8.5 8C7.67157 8 7 8.67157 7 9.5C7 10.3284 7.67157 11 8.5 11Z" fill="#9a9aaa"/>
        <path d="M15.5 11C16.3284 11 17 10.3284 17 9.5C17 8.67157 16.3284 8 15.5 8C14.6716 8 14 8.67157 14 9.5C14 10.3284 14.6716 11 15.5 11Z" fill="#9a9aaa"/>
        <path d="M12 2C6.5 2 2 5.58 2 10C2 12.05 3 13.85 4.64 15.15C4.45 16.45 3.5 18.5 3.5 18.5C3.5 18.5 6.5 18.15 8.35 17.5C9.5 17.82 10.72 18 12 18C17.5 18 22 14.42 22 10C22 5.58 17.5 2 12 2Z" stroke="#9a9aaa" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M16 15.5C16 15.5 14.5 17 12 17C9.5 17 8 15.5 8 15.5" stroke="#9a9aaa" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] transition-colors relative rounded-[12px] shrink-0 size-[36px] flex items-center justify-center border border-[rgba(100,100,110,0.3)]" data-name="Button">
      <Icon />
    </div>
  );
}

function Icon1() {
  return (
    <div className="h-[20px] overflow-visible relative shrink-0 w-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" viewBox="0 0 24 24">
        <path d="M19.27 5.33C17.94 4.71 16.5 4.26 15 4a.09.09 0 0 0-.07.03c-.18.33-.39.76-.53 1.09a16.09 16.09 0 0 0-4.8 0c-.14-.34-.35-.76-.54-1.09c-.01-.02-.04-.03-.07-.03c-1.5.26-2.93.71-4.27 1.33c-.01 0-.02.01-.03.02c-2.72 4.07-3.47 8.03-3.1 11.95c0 .02.01.04.03.05c1.8 1.32 3.53 2.12 5.24 2.65c.03.01.06 0 .07-.02c.4-.55.76-1.13 1.07-1.74c.02-.04 0-.08-.04-.09c-.57-.22-1.11-.48-1.64-.78c-.04-.02-.04-.08-.01-.11c.11-.08.22-.17.33-.25c.02-.02.05-.02.07-.01c3.44 1.57 7.15 1.57 10.55 0c.02-.01.05-.01.07.01c.11.09.22.17.33.26c.04.03.04.09-.01.11c-.52.31-1.07.56-1.64.78c-.04.01-.05.06-.04.09c.32.61.68 1.19 1.07 1.74c.03.01.06.02.09.01c1.72-.53 3.45-1.33 5.25-2.65c.02-.01.03-.03.03-.05c.44-4.53-.73-8.46-3.1-11.95c-.01-.01-.02-.02-.04-.02zM8.52 14.91c-1.03 0-1.89-.95-1.89-2.12s.84-2.12 1.89-2.12c1.06 0 1.9.96 1.89 2.12c0 1.17-.84 2.12-1.89 2.12zm6.97 0c-1.03 0-1.89-.95-1.89-2.12s.84-2.12 1.89-2.12c1.06 0 1.9.96 1.89 2.12c0 1.17-.83 2.12-1.89 2.12z" fill="#9a9aaa"/>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] transition-colors relative rounded-[12px] shrink-0 size-[36px] flex items-center justify-center border border-[rgba(100,100,110,0.3)]" data-name="Button">
      <Icon1 />
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-[#2a2a35] hover:bg-[#3a3a45] transition-colors h-[32px] relative rounded-[14px] shrink-0 px-4 flex items-center justify-center" data-name="Button">
      <p className="css-ew64yg font-['Arial:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] leading-[20px] text-[14px] text-center text-[#e8e8ec] whitespace-nowrap" style={{ fontVariationSettings: "'wght' 400" }}>
        登录
      </p>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-gradient-to-r from-[#8a8a95] hover:from-[#9a9aa5] hover:to-[#7a7a85] transition-colors h-[32px] relative rounded-[14px] shrink-0 px-4 flex items-center justify-center to-[#6a6a75]" data-name="Button">
      <p className="css-ew64yg font-['Arial:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] leading-[20px] text-[14px] text-center text-[#e8e8ec] whitespace-nowrap" style={{ fontVariationSettings: "'wght' 400" }}>
        使用邀请码加入
      </p>
    </div>
  );
}

function Container3() {
  return (
    <div className="h-[36px] relative shrink-0" data-name="Container">
      <div className="flex gap-[16px] items-center h-full">
        <Link />
        <Button />
        <Button1 />
        <Button2 />
        <Button3 />
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="absolute content-stretch flex h-[68px] items-center justify-between left-0 px-[32px] top-0 w-[1678.4px]" data-name="Navigation">
      <Container2 />
      <Container3 />
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[20px] relative shrink-0 w-[19.225px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['Arial:Regular',sans-serif] leading-[20px] left-0 not-italic text-[#51a2ff] text-[14px] top-[-1.2px]">💡</p>
      </div>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[20px] relative shrink-0 w-[456.587px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['Arial:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] leading-[20px] left-0 text-[#c1c5cc] text-[14px] top-[-1.2px]" style={{ fontVariationSettings: "'wght' 400" }}>{`全新好玩功能到了！点击左上方"导出动画"立即体验，制服神奇有一身吗~`}</p>
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div className="h-[20px] relative shrink-0 w-[483.813px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Text2 />
        <Text3 />
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="h-[18px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-1/4" data-name="Vector">
        <div className="absolute inset-[-8.33%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.5 10.5">
            <path d="M9.75 0.75L0.75 9.75" id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-1/4" data-name="Vector">
        <div className="absolute inset-[-8.33%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.5 10.5">
            <path d="M0.75 0.75L9.75 9.75" id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button4() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon2 />
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute bg-gradient-to-r content-stretch flex from-[rgba(26,26,35,0.85)] h-[45.6px] items-center justify-between left-[519.2px] px-[24.8px] py-[0.8px] rounded-[16px] to-[rgba(35,35,45,0.85)] top-[84px] w-[640px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(80,80,95,0.3)] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container4 />
      <Button4 />
    </div>
  );
}

function Heading() {
  return (
    <div className="relative shrink-0 min-w-full overflow-visible" data-name="Heading 1">
      <p className="bg-clip-text css-ew64yg font-['Arial:Bold_Italic',sans-serif] italic leading-[72px] text-[72px] text-[rgba(0,0,0,0)] text-center whitespace-nowrap px-4" style={{ WebkitTextFillColor: "transparent", backgroundImage: "linear-gradient(90deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0) 100%), linear-gradient(90deg, rgb(235, 235, 240) 0%, rgb(180, 185, 195) 100%)" }}>{`Make  GAME  World`}</p>
    </div>
  );
}

function Heading1() {
  return (
    <div className="relative shrink-0 min-w-full overflow-visible" data-name="Heading 1">
      <p className="bg-clip-text css-ew64yg font-['Arial:Bold_Italic',sans-serif] italic leading-[72px] text-[72px] text-[rgba(0,0,0,0)] text-center whitespace-nowrap px-4" style={{ WebkitTextFillColor: "transparent", backgroundImage: "linear-gradient(90deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0) 100%), linear-gradient(90deg, rgb(235, 235, 240) 0%, rgb(180, 185, 195) 100%)" }}>
        Great Again
      </p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="relative shrink-0 w-full shimmer-text-container" data-name="Paragraph">
      <p className="shimmer-text css-ew64yg font-['Arial:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] leading-[24px] text-[16px] text-center m-0 p-0" style={{ fontVariationSettings: "'wght' 400" }}>
        基于LLM启发式构想的世界规则生成器
      </p>
    </div>
  );
}

function Container6() {
  return (
    <div className="relative shrink-0 min-w-max" data-name="Container">
      <div className="flex flex-col gap-[24px] items-center relative min-w-max">
        <Heading />
        <Heading1 />
        <Paragraph />
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="h-[100px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[35%_27.78%_15%_27.78%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 50">
          <path d={svgPaths.p2e82ed32} fill="var(--fill-0, #FF69B4)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[12%_30%_52%_30%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
          <path d={svgPaths.p11f24a00} fill="var(--fill-0, #FF69B4)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[3.5%_45.05%_85%_45.05%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.90909 11.5">
          <path d={svgPaths.p3add2280} fill="var(--fill-0, #FF69B4)" id="Vector" />
        </svg>
      </div>
      <div className="absolute bottom-[69%] left-[41.11%] right-[52.22%] top-1/4" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
          <path d={svgPaths.p969ae00} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute bottom-[69%] left-[52.22%] right-[41.11%] top-1/4" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
          <path d={svgPaths.p969ae00} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[26.5%_52.78%_70.5%_43.89%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 3 3">
          <path d={svgPaths.p3cbff000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[26.5%_41.67%_70.5%_55%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 3 3">
          <path d={svgPaths.p3cbff000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
      <div className="absolute flex inset-[38.01%_50.64%_28.01%_17.3%] items-center justify-center">
        <div className="flex-none h-[30px] rotate-[-30deg] w-[16px]">
          <div className="relative size-full" data-name="Vector">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 30">
              <path d={svgPaths.p2efef100} fill="var(--fill-0, #FF69B4)" id="Vector" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function CharacterIllustration() {
  return (
    <div className="absolute content-stretch flex flex-col h-[100px] items-start left-0 shadow-[0px_10px_60px_0px_rgba(0,0,0,0.5)] top-[80px] w-[90px]" data-name="CharacterIllustration">
      <Icon3 />
    </div>
  );
}

function Icon4() {
  return (
    <div className="h-[100px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[55%_33.33%_15%_33.33%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
          <path d={svgPaths.p46b8500} fill="var(--fill-0, #FF4444)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[15%_27.78%_45%_27.78%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
          <path d={svgPaths.p1fd92980} fill="var(--fill-0, #FF4444)" id="Vector" />
        </svg>
      </div>
      <div className="absolute bottom-3/4 left-[38.89%] right-[38.89%] top-[10%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 15">
          <path d={svgPaths.p13ed5440} fill="var(--fill-0, #FF6B6B)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[31%_53.33%_61%_37.78%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p65069f0} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[31%_37.78%_61%_53.33%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p65069f0} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[33%_54.44%_63%_41.11%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 4 4">
          <path d={svgPaths.p12ed5580} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[33%_38.89%_63%_56.67%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 4 4">
          <path d={svgPaths.p12ed5580} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function CharacterIllustration1() {
  return (
    <div className="absolute content-stretch flex flex-col h-[100px] items-start left-[106px] shadow-[0px_10px_60px_0px_rgba(0,0,0,0.5)] top-[80px] w-[90px]" data-name="CharacterIllustration">
      <Icon4 />
    </div>
  );
}

function Icon5() {
  return (
    <div className="h-[100px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[35%_33.33%_5%_33.33%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 60">
          <path d={svgPaths.p1f2bf500} fill="var(--fill-0, #9B59B6)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[10%_33.33%_60%_33.33%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
          <path d={svgPaths.p7c58b00} fill="var(--fill-0, #9B59B6)" id="Vector" />
        </svg>
      </div>
      <div className="absolute bottom-[90%] left-1/2 right-1/2 top-[2%]" data-name="Vector">
        <div className="absolute inset-[0_-1.5px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 3 8">
            <path d="M1.5 8V0" id="Vector" stroke="var(--stroke-0, #9B59B6)" strokeWidth="3" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[-2%_45.56%_94%_45.56%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p65069f0} fill="var(--fill-0, #E8B4F0)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[22%_52.22%_72%_41.11%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
          <path d={svgPaths.p969ae00} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[22%_41.11%_72%_52.22%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
          <path d={svgPaths.p969ae00} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function CharacterIllustration2() {
  return (
    <div className="absolute content-stretch flex flex-col h-[100px] items-start left-[212px] shadow-[0px_10px_60px_0px_rgba(0,0,0,0.5)] top-[80px] w-[90px]" data-name="CharacterIllustration">
      <Icon5 />
    </div>
  );
}

function Icon6() {
  return (
    <div className="h-[180px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_18.75%_11.11%_18.75%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 100 100">
          <path d={svgPaths.p11c4dd80} fill="var(--fill-0, #4DD9D9)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[2.78%_21.88%_58.33%_21.88%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 90 70">
          <path d={svgPaths.p10a46400} fill="var(--fill-0, #4DD9D9)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[1.67%_57.5%_85%_32.5%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 24">
          <path d={svgPaths.p3e4a3000} fill="var(--fill-0, #7FECEC)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[1.67%_32.5%_85%_57.5%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 24">
          <path d={svgPaths.p3e4a3000} fill="var(--fill-0, #7FECEC)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[21.67%_55.63%_71.67%_36.88%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
          <path d={svgPaths.p2ca50880} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[21.67%_36.88%_71.67%_55.63%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
          <path d={svgPaths.p2ca50880} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[23.33%_56.25%_73.33%_40%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
          <path d={svgPaths.p969ae00} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[23.33%_37.5%_73.33%_58.75%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
          <path d={svgPaths.p969ae00} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
      <div className="absolute bottom-1/4 left-[34.38%] right-[34.38%] top-[55.56%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 50 35">
          <path d={svgPaths.p36b81700} fill="var(--fill-0, #3AA3A3)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[36.11%_83.13%_36.11%_1.88%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 50">
          <path d={svgPaths.pe13c3c0} fill="var(--fill-0, #4DD9D9)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[36.11%_1.88%_36.11%_83.13%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 50">
          <path d={svgPaths.pe13c3c0} fill="var(--fill-0, #4DD9D9)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[86.11%_56.25%_2.78%_31.25%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
          <path d={svgPaths.p3004bd30} fill="var(--fill-0, #3AA3A3)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[86.11%_31.25%_2.78%_56.25%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
          <path d={svgPaths.p3004bd30} fill="var(--fill-0, #3AA3A3)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function CharacterIllustration3() {
  return (
    <div className="absolute content-stretch flex flex-col h-[180px] items-start left-[318px] shadow-[0px_10px_60px_0px_rgba(0,0,0,0.5)] top-0 w-[160px]" data-name="CharacterIllustration">
      <Icon6 />
    </div>
  );
}

function Icon7() {
  return (
    <div className="h-[100px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[37%_30%_7%_30%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 56">
          <path d={svgPaths.p34a87900} fill="var(--fill-0, #FFD93D)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[12%_32.22%_56%_32.22%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
          <path d={svgPaths.p1199c300} fill="var(--fill-0, #FFD93D)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[8%_57.78%_68%_28.89%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 24">
          <path d={svgPaths.p2a299d00} fill="var(--fill-0, #FFD93D)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[8%_28.89%_68%_57.78%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 24">
          <path d={svgPaths.p2a299d00} fill="var(--fill-0, #FFD93D)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[23%_52.22%_71%_41.11%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
          <path d={svgPaths.p969ae00} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[23%_41.11%_71%_52.22%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
          <path d={svgPaths.p969ae00} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[30%_47.78%_66%_47.78%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 4 4">
          <path d={svgPaths.p12ed5580} fill="var(--fill-0, #E8B93D)" id="Vector" />
        </svg>
      </div>
      <div className="absolute flex inset-[43.17%_54.84%_23.17%_17.06%] items-center justify-center">
        <div className="flex-none h-[30px] rotate-[-20deg] w-[16px]">
          <div className="relative size-full" data-name="Vector">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 30">
              <path d={svgPaths.p2efef100} fill="var(--fill-0, #FFD93D)" id="Vector" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute flex inset-[43.17%_17.06%_23.17%_54.84%] items-center justify-center">
        <div className="flex-none h-[30px] rotate-[20deg] w-[16px]">
          <div className="relative size-full" data-name="Vector">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 30">
              <path d={svgPaths.p2efef100} fill="var(--fill-0, #FFD93D)" id="Vector" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function CharacterIllustration4() {
  return (
    <div className="absolute content-stretch flex flex-col h-[100px] items-start left-[494px] shadow-[0px_10px_60px_0px_rgba(0,0,0,0.5)] top-[80px] w-[90px]" data-name="CharacterIllustration">
      <Icon7 />
    </div>
  );
}

function Icon8() {
  return (
    <div className="h-[100px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-[10%] left-[25.56%] right-[25.56%] top-1/2" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 44 40">
          <path d={svgPaths.p390d2300} fill="var(--fill-0, #6AB7FF)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[37%_27.78%_27%_27.78%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 36">
          <path d={svgPaths.p1e791b00} fill="var(--fill-0, #8DC7FF)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[15%_33.33%_57%_33.33%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 28">
          <path d={svgPaths.p3986d980} fill="var(--fill-0, #6AB7FF)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[10%_38.89%_82%_38.89%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 8">
          <path d={svgPaths.p69c6500} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute bottom-[69%] left-[38.89%] right-[54.44%] top-1/4" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
          <path d={svgPaths.p969ae00} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute bottom-[69%] left-[54.44%] right-[38.89%] top-1/4" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
          <path d={svgPaths.p969ae00} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[26.5%_55%_70.5%_41.67%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 3 3">
          <path d={svgPaths.p3cbff000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[26.5%_39.44%_70.5%_57.22%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 3 3">
          <path d={svgPaths.p3cbff000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function CharacterIllustration5() {
  return (
    <div className="absolute content-stretch flex flex-col h-[100px] items-start left-[600px] shadow-[0px_10px_60px_0px_rgba(0,0,0,0.5)] top-[80px] w-[90px]" data-name="CharacterIllustration">
      <Icon8 />
    </div>
  );
}

function Icon9() {
  return (
    <div className="h-[100px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-[15%] left-[33.33%] right-[33.33%] top-1/2" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 35">
          <path d={svgPaths.pf6af100} fill="var(--fill-0, #A0D468)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[16%_34.44%_56%_34.44%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28 28">
          <path d={svgPaths.pc390800} fill="var(--fill-0, #A0D468)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[22%_41.11%_62%_41.11%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
          <path d={svgPaths.p30769300} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[26%_45.56%_66%_45.56%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p65069f0} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
      <div className="absolute bottom-[84%] left-1/2 right-1/2 top-[8%]" data-name="Vector">
        <div className="absolute inset-[0_-1px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2 8">
            <path d="M1 8V0" id="Vector" stroke="var(--stroke-0, #A0D468)" strokeWidth="2" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[5%_46.67%_89%_46.67%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
          <path d={svgPaths.p969ae00} fill="var(--fill-0, #C4E87A)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function CharacterIllustration6() {
  return (
    <div className="absolute content-stretch flex flex-col h-[100px] items-start left-[706px] shadow-[0px_10px_60px_0px_rgba(0,0,0,0.5)] top-[80px] w-[90px]" data-name="CharacterIllustration">
      <Icon9 />
    </div>
  );
}

function Container7() {
  return (
    <div className="h-[180px] relative shrink-0 w-[796px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full flex items-end justify-center gap-[16px]">
        {/* 1. 地质学与气候学家 - 战士 */}
        <div className="relative w-[120px] h-[160px] group">
          <div className="w-full h-full overflow-hidden shadow-[0px_10px_60px_0px_rgba(0,0,0,0.5)] border-2 border-[rgba(139,69,19,0.6)]" style={{ imageRendering: 'pixelated' }}>
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1765606290905-b9d377ea4d5e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwd2FycmlvciUyMGNoYXJhY3RlcnxlbnwxfHx8fDE3NjkxMTY2NjZ8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="地质学与气候学家"
              className="w-full h-full object-cover saturate-[1.2] contrast-[1.1] brightness-[0.9] transition-all duration-300 group-hover:scale-110"
            />
          </div>
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[rgba(139,69,19,0.95)] to-transparent p-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <p className="text-[#f4e4c1] text-xs text-center font-['Arial'] font-bold" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.8)' }}>地质学家</p>
          </div>
        </div>

        {/* 2. 人类学家与社会学家 - 学者 */}
        <div className="relative w-[120px] h-[160px] group">
          <div className="w-full h-full overflow-hidden shadow-[0px_10px_60px_0px_rgba(0,0,0,0.5)] border-2 border-[rgba(70,130,180,0.6)]" style={{ imageRendering: 'pixelated' }}>
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1741805190358-aff8c1c1d72a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxycGclMjBjaGFyYWN0ZXIlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NjkxODUyMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="人类学家与社会学家"
              className="w-full h-full object-cover saturate-[1.2] contrast-[1.1] brightness-[0.9] transition-all duration-300 group-hover:scale-110"
            />
          </div>
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[rgba(70,130,180,0.95)] to-transparent p-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <p className="text-[#e6f2ff] text-xs text-center font-['Arial'] font-bold" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.8)' }}>人类学家</p>
          </div>
        </div>

        {/* 3. 语言学家 - 盗贼 */}
        <div className="relative w-[120px] h-[160px] group">
          <div className="w-full h-full overflow-hidden shadow-[0px_10px_60px_0px_rgba(0,0,0,0.5)] border-2 border-[rgba(128,0,128,0.6)]" style={{ imageRendering: 'pixelated' }}>
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1692306088530-e81ab626753b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaXhlbCUyMGFydCUyMHJvZ3VlJTIwdGhpZWZ8ZW58MXx8fHwxNzY5MTg1MjEyfDA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="语言学家"
              className="w-full h-full object-cover saturate-[1.2] contrast-[1.1] brightness-[0.9] transition-all duration-300 group-hover:scale-110"
            />
          </div>
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[rgba(128,0,128,0.95)] to-transparent p-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <p className="text-[#f4d4ff] text-xs text-center font-['Arial'] font-bold" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.8)' }}>语言学家</p>
          </div>
        </div>

        {/* 4. 经济学家 - 商人 */}
        <div className="relative w-[120px] h-[160px] group">
          <div className="w-full h-full overflow-hidden shadow-[0px_10px_60px_0px_rgba(0,0,0,0.5)] border-2 border-[rgba(218,165,32,0.6)]" style={{ imageRendering: 'pixelated' }}>
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1644007497105-8d0ae9ec9754?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaXhlbCUyMGFydCUyMG1lcmNoYW50JTIwdHJhZGVyfGVufDF8fHx8MTc2OTE4NTIxMnww&ixlib=rb-4.1.0&q=80&w=1080"
              alt="经济学家"
              className="w-full h-full object-cover saturate-[1.2] contrast-[1.1] brightness-[0.9] transition-all duration-300 group-hover:scale-110"
            />
          </div>
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[rgba(218,165,32,0.95)] to-transparent p-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <p className="text-[#fff8dc] text-xs text-center font-['Arial'] font-bold" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.8)' }}>经济学家</p>
          </div>
        </div>

        {/* 5. 历史学家与考古学家 - 神官 */}
        <div className="relative w-[120px] h-[160px] group">
          <div className="w-full h-full overflow-hidden shadow-[0px_10px_60px_0px_rgba(0,0,0,0.5)] border-2 border-[rgba(255,215,0,0.6)]" style={{ imageRendering: 'pixelated' }}>
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1644007497105-8d0ae9ec9754?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaXhlbCUyMGFydCUyMGNsZXJpYyUyMHByaWVzdHxlbnwxfHx8fDE3NjkxODUyMTJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="历史学家与考古学家"
              className="w-full h-full object-cover saturate-[1.2] contrast-[1.1] brightness-[0.9] transition-all duration-300 group-hover:scale-110"
            />
          </div>
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[rgba(255,215,0,0.95)] to-transparent p-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <p className="text-[#fffacd] text-xs text-center font-['Arial'] font-bold" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.8)' }}>历史学家</p>
          </div>
        </div>

        {/* 6. 政治学家与军事专家 - 猎人 */}
        <div className="relative w-[120px] h-[160px] group">
          <div className="w-full h-full overflow-hidden shadow-[0px_10px_60px_0px_rgba(0,0,0,0.5)] border-2 border-[rgba(34,139,34,0.6)]" style={{ imageRendering: 'pixelated' }}>
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1606150062964-77af827610fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaXhlbCUyMGFydCUyMGh1bnRlciUyMGFyY2hlcnxlbnwxfHx8fDE3NjkxODUyMTN8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="政治学家与军事专家"
              className="w-full h-full object-cover saturate-[1.2] contrast-[1.1] brightness-[0.9] transition-all duration-300 group-hover:scale-110"
            />
          </div>
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[rgba(34,139,34,0.95)] to-transparent p-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <p className="text-[#e0ffe0] text-xs text-center font-['Arial'] font-bold" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.8)' }}>军事专家</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function TextInput() {
  return (
    <div className="content-stretch flex h-[20px] items-center overflow-clip relative shrink-0 w-full" data-name="Text Input">
      <p className="css-ew64yg font-['Arial:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] leading-[normal] relative shrink-0 text-[#7a7a88] text-[14px]" style={{ fontVariationSettings: "'wght' 400" }}>
        请用一句话描述你脑海里中的世界最特殊的地方!!!!
      </p>
    </div>
  );
}

function Icon10() {
  return (
    <div className="h-[18px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-1/2 left-[20.83%] right-[20.83%] top-1/2" data-name="Vector">
        <div className="absolute inset-[-0.75px_-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 1.5">
            <path d="M0.75 0.75H11.25" id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-[20.83%] left-1/2 right-1/2 top-[20.83%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-0.75px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.5 12">
            <path d="M0.75 0.75V11.25" id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button5() {
  return (
    <div 
      className="relative rounded-[12px] shrink-0 w-[40px] h-[40px] bg-[rgba(50,50,60,0.6)] hover:bg-[rgba(65,65,75,0.8)] border border-[rgba(100,100,115,0.3)] hover:border-[rgba(130,130,145,0.5)] transition-all duration-300 cursor-pointer flex items-center justify-center" 
      data-name="Button"
    >
      <div className="w-[18px] h-[18px] flex items-center justify-center">
        <Icon10 />
      </div>
    </div>
  );
}

function Icon11() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p9145900} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p2daff3c0} id="Vector_2" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 14.6667V8" id="Vector_3" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text4() {
  return (
    <div className="flex-[1_0_0] h-[15.988px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="css-4hzbpn flex-[1_0_0] font-['Arial:Regular','Noto_Sans_JP:Regular',sans-serif] leading-[16px] min-h-px min-w-px relative text-[#c1c5cc] text-[12px] text-center" style={{ fontVariationSettings: "'wght' 400" }}>
          角色
        </p>
      </div>
    </div>
  );
}

function Button6() {
  return (
    <div 
      className="h-[40px] relative rounded-[12px] shrink-0 px-[14px] bg-[rgba(50,50,60,0.6)] hover:bg-[rgba(65,65,75,0.8)] border border-[rgba(100,100,115,0.3)] hover:border-[rgba(130,130,145,0.5)] transition-all duration-300 cursor-pointer" 
      data-name="Button"
    >
      <div className="flex gap-[6px] items-center justify-center h-full">
        <Icon11 />
        <Text4 />
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="h-[40px] relative shrink-0 flex items-center" data-name="Container">
      <div className="flex gap-[12px] items-center">
        <Button5 />
        <Button6 />
      </div>
    </div>
  );
}

function Icon12() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_1_156)" id="Icon">
          <path d={svgPaths.p15ab3e60} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M13.3333 1.33333V4" id="Vector_2" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M14.6667 2.66667H12" id="Vector_3" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p22966600} id="Vector_4" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_1_156">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text5() {
  return (
    <div className="flex-[1_0_0] h-[15.988px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="css-4hzbpn flex-[1_0_0] font-['Arial:Regular','Noto_Sans_JP:Regular',sans-serif] leading-[16px] min-h-px min-w-px relative text-[#c1c5cc] text-[12px] text-center" style={{ fontVariationSettings: "'wght' 400" }}>
          灵感随机
        </p>
      </div>
    </div>
  );
}

function Button7() {
  return (
    <div 
      className="h-[40px] relative rounded-[12px] px-[14px] bg-[rgba(50,50,60,0.6)] hover:bg-[rgba(65,65,75,0.8)] border border-[rgba(100,100,115,0.3)] hover:border-[rgba(130,130,145,0.5)] transition-all duration-300 cursor-pointer" 
      data-name="Button"
    >
      <div className="flex gap-[6px] items-center justify-center h-full">
        <Icon12 />
        <Text5 />
      </div>
    </div>
  );
}

function Text6() {
  return (
    <div className="h-[15.988px] relative shrink-0 w-[48px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="css-4hzbpn flex-[1_0_0] font-['Arial:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] leading-[16px] min-h-px min-w-px relative text-[#7a7a88] text-[12px]" style={{ fontVariationSettings: "'wght' 400" }}>
          高级模式
        </p>
      </div>
    </div>
  );
}

function Icon13() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d="M8 5V15L15 10L8 5Z" fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Button8() {
  return (
    <div 
      className="relative rounded-[16px] shrink-0 w-[56px] h-[40px] backdrop-blur-xl bg-[rgba(255,255,255,0.08)] hover:bg-[rgba(255,255,255,0.12)] border border-[rgba(255,255,255,0.18)] hover:border-[rgba(255,255,255,0.25)] shadow-[0_4px_16px_rgba(0,0,0,0.2),inset_0_1px_0_rgba(255,255,255,0.2)] transition-all duration-300 cursor-pointer" 
      data-name="Button"
    >
      <div className="flex items-center justify-center size-full">
        <Icon13 />
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="h-[40px] relative shrink-0 flex items-center" data-name="Container">
      <div className="flex gap-[12px] items-center">
        <Button7 />
        <Text6 />
        <Button8 />
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="content-stretch flex h-[40px] items-center justify-between relative shrink-0 w-full bg-[rgba(0,0,0,0)]" data-name="Container">
      <Container8 />
      <Container9 />
    </div>
  );
}

function Container11() {
  return (
    <div className="bg-gradient-to-r from-[rgba(26,26,35,0.92)] h-[109.6px] relative rounded-[20px] shrink-0 to-[rgba(35,35,45,0.92)] w-[672px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(80,80,95,0.3)] border-solid inset-0 pointer-events-none rounded-[20px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[16px] items-start pb-[0.8px] pt-[16.8px] px-[16.8px] relative size-full">
        <TextInput />
        <Container10 />
      </div>
    </div>
  );
}

function MainContent() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[48px] h-[737.6px] items-center justify-center left-0 top-[129.6px] w-[1678.4px]" data-name="Main Content">
      <Container6 />
      <Container7 />
      <Container11 />
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-transparent relative size-full" data-name="生成相同结构网页">
      <Container />
      <Navigation />
      <Container5 />
      <MainContent />
    </div>
  );
}