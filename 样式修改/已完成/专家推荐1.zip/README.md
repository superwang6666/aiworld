
  # 游戏世界页面设计

  This is a code bundle for 游戏世界页面设计. The original project is available at https://www.figma.com/design/TLIR7U2y2WbYV0LjxAoY6Y/%E6%B8%B8%E6%88%8F%E4%B8%96%E7%95%8C%E9%A1%B5%E9%9D%A2%E8%AE%BE%E8%AE%A1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  