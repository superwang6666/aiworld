import svgPaths from "./svg-78xtiwj304";
import imgRectangle6 from "figma:asset/6d6df86e2c8fe0dcfbb3f8b3c4a55c8564b130e6.png";
import imgImage2 from "figma:asset/b66683c091f47ee48661fec2c0e1b455be6a833e.png";
import img11112 from "figma:asset/14471b84f8645629a2e2d15820843ae0259df11a.png";
import img22221 from "figma:asset/50b02d359fa74e6613dff4087bb9306d1149af55.png";
import imgImage3 from "figma:asset/130c10626671402881a70fd48a5acbd159994da2.png";

function Text() {
  return (
    <div className="flex-[1_0_0] h-[24px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Arial:Black',sans-serif] leading-[24px] left-0 not-italic text-[#39ff14] text-[16px] top-[2px] tracking-[0.8px]">WORLD</p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="bg-gradient-to-b flex-[1_0_0] from-[rgba(35,35,45,0.9)] h-[42px] min-h-px min-w-px relative rounded-[18px] to-[rgba(45,45,55,0.9)]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,115,0.4)] border-solid inset-0 pointer-events-none rounded-[18px]" />
      <div className="flex flex-row items-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center px-[17px] py-px relative size-full">
          <Text />
        </div>
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="content-stretch flex h-[14px] items-start relative shrink-0 w-full" data-name="Text">
      <p className="font-['Arial:Regular',sans-serif] leading-[16.5px] not-italic relative shrink-0 text-[#c1c5cc] text-[11px] tracking-[0.55px]">BETA</p>
    </div>
  );
}

function Container2() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] h-[34px] relative rounded-[18px] shrink-0 w-[54.328px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[18px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-px pt-[12px] px-[13px] relative size-full">
        <Text1 />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="h-[42px] relative shrink-0 w-[167.234px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container1 />
        <Container2 />
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] flex-[1_0_0] h-[39px] min-h-px min-w-px relative rounded-[14px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[17px] py-[9px] relative size-full">
        <p className="font-['Arial:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] leading-[21px] relative shrink-0 text-[#e8e8ec] text-[14px] text-center" style={{ fontVariationSettings: "'wght' 400" }}>
          简体中文
        </p>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_83)" id="Icon">
          <path d={svgPaths.p2b260000} id="Vector" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_83">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] relative rounded-[12px] shrink-0 size-[36px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-px relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p1d939600} id="Vector" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p5272800} id="Vector_2" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] relative rounded-[12px] shrink-0 size-[36px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-px relative size-full">
        <Icon1 />
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_1_86)" id="Icon">
          <path d={svgPaths.p3a6156f0} id="Vector" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p11fb83c0} id="Vector_2" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M4.66667 4H5.33333V6.66667" id="Vector_3" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p583e380} id="Vector_4" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_1_86">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text2() {
  return (
    <div className="flex-[1_0_0] h-[19.5px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Arial:Regular',sans-serif] leading-[19.5px] left-0 not-italic text-[#e8e8ec] text-[13px] top-[-1px]">1,145</p>
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] h-[33.5px] relative rounded-[12px] shrink-0 w-[83.625px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center px-[13px] py-px relative size-full">
        <Icon2 />
        <Text2 />
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p1beb9580} id="Vector" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p32ab0300} id="Vector_2" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] relative rounded-[12px] shrink-0 size-[36px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-px relative size-full">
        <Icon3 />
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p654be80} id="Vector" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] relative rounded-[12px] shrink-0 size-[36px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-px relative size-full">
        <Icon4 />
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="h-[39px] relative shrink-0 w-[377.625px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Button />
        <Button1 />
        <Button2 />
        <Container4 />
        <Button3 />
        <Button4 />
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="absolute content-stretch flex h-[90px] items-center justify-between left-0 px-[64px] top-0 w-[1534px]" data-name="Navigation">
      <Container />
      <Container3 />
    </div>
  );
}

function Frame2() {
  return (
    <div className="h-[580px] overflow-clip relative shrink-0 w-[687px]">
      <div className="absolute bg-[#d9d9d9] inset-0 rounded-[60px]" />
      <div className="absolute inset-[12.93%_6.99%_3.79%_9.75%] rounded-[60px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[60px] size-full" src={imgRectangle6} />
      </div>
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal inset-[2.59%_6.99%_87.07%_9.75%] leading-[normal] not-italic text-[40px] text-black whitespace-pre-wrap">独特性评分:70/100[独一无二的]</p>
      <div className="absolute bg-white h-[61px] left-[283px] top-[344px] w-[141px]" />
      <div className="absolute bg-white h-[82px] left-[371px] top-[249px] w-[86px]" />
    </div>
  );
}

function Frame() {
  return (
    <div className="h-[580px] overflow-clip relative shrink-0 w-[687px]">
      <div className="absolute bg-[#d9d9d9] h-[580px] left-0 rounded-[60px] top-0 w-[687px]" />
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal inset-[3.62%_36.39%_88.1%_22.85%] leading-[normal] not-italic text-[40px] text-black">核心异常已识别</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular','Noto_Sans:Regular',sans-serif] font-normal h-[293px] leading-[normal] left-[89px] not-italic text-[48px] text-black top-[102px] w-[491px] whitespace-pre-wrap">{`形而上学：该前提通过引入与说谎行为直接相关的超自然、物理后果（阴茎生长）来扰乱形而上学的法则，这从根本上改变了这个世界的现实和因果关系。 `}</p>
      <div className="absolute h-[48px] left-[78px] top-[21px] w-[52px]" data-name="image 2">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage2} />
      </div>
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex gap-[4px] h-[595px] items-center justify-center left-[19px] top-[108px] w-[1496px]">
      <Frame2 />
      <Frame />
    </div>
  );
}

function Group() {
  return (
    <div className="col-1 grid-cols-[max-content] grid-rows-[max-content] inline-grid items-[start] justify-items-[start] ml-0 mt-[227.43px] relative row-1">
      <div className="col-1 h-[154.613px] ml-0 mt-0 relative row-1 w-[734.996px]" data-name="1111 2">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[549.25%] left-[-2.54%] max-w-none top-[-144.72%] w-[205.71%]" src={img11112} />
        </div>
      </div>
      <div className="col-1 h-[154.613px] ml-[735px] mt-0 relative row-1 w-[734.996px]" data-name="1111 4">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[549.25%] left-[-102.85%] max-w-none top-[-144.13%] w-[205.71%]" src={img11112} />
        </div>
      </div>
      <div className="col-1 h-[154.613px] ml-0 mt-[160.83px] relative row-1 w-[734.996px]" data-name="1111 5">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[549.25%] left-[-2.86%] max-w-none top-[-242.19%] w-[205.71%]" src={img11112} />
        </div>
      </div>
      <div className="col-1 h-[154.613px] ml-[735px] mt-[160.83px] relative row-1 w-[734.996px]" data-name="1111 6">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[549.25%] left-[-102.9%] max-w-none top-[-242.19%] w-[205.71%]" src={img11112} />
        </div>
      </div>
      <div className="col-1 h-[154.613px] ml-0 mt-[321.66px] relative row-1 w-[734.996px]" data-name="1111 7">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[549.25%] left-[-2.82%] max-w-none top-[-335.98%] w-[205.71%]" src={img11112} />
        </div>
      </div>
      <div className="col-1 h-[154.613px] ml-[735px] mt-[321.66px] relative row-1 w-[734.996px]" data-name="1111 8">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[549.25%] left-[-102.84%] max-w-none top-[-333.85%] w-[205.71%]" src={img11112} />
        </div>
      </div>
      <div className="col-1 h-[154.613px] ml-0 mt-[482.49px] relative row-1 w-[734.996px]" data-name="1111 9">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[549.25%] left-[-2.84%] max-w-none top-[-431.9%] w-[205.71%]" src={img11112} />
        </div>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid items-[start] justify-items-[start] leading-[0] relative shrink-0">
      <div className="col-1 h-[227.428px] ml-[4.52px] mt-0 relative row-1 w-[1465.482px]" data-name="1111 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[361.92%] left-0 max-w-none top-0 w-full" src={img11112} />
        </div>
      </div>
      <Group />
    </div>
  );
}

function Group2() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid items-[start] justify-items-[start] leading-[0] relative shrink-0">
      <div className="bg-[#d9d9d9] col-1 h-[54px] ml-[4px] mt-[3px] rounded-[21.5px] row-1 w-[456px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 col-1 flex flex-col font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal h-[57px] justify-center ml-[230px] mt-[28.5px] not-italic relative row-1 text-[24px] text-black text-center w-[460px]">
        <p className="leading-[normal] whitespace-pre-wrap">跳转至高级分析阶段</p>
      </div>
    </div>
  );
}

function Context() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[12px] items-center left-[19px] top-[721px] w-[1496px]" data-name="context">
      <Group1 />
      <div className="aspect-[1496/446] relative shrink-0 w-full" data-name="2222 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[201.84%] left-0 max-w-none top-[-0.02%] w-full" src={img22221} />
        </div>
      </div>
      <div className="aspect-[1496/443] relative shrink-0 w-full" data-name="2222 2">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[203.2%] left-0 max-w-none top-[-103.18%] w-full" src={img22221} />
        </div>
      </div>
      <div className="h-[85px] relative shrink-0 w-[1502px]" data-name="image 3">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage3} />
      </div>
      <Group2 />
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-[#0f0f14] relative size-full" data-name="初步分析阶段">
      <Navigation />
      <Frame1 />
      <Context />
    </div>
  );
}