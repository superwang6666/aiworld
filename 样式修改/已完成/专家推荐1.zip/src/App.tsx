import { motion } from "motion/react";
import {
  Globe,
  ChevronDown,
  User,
  Clock,
  Share2,
  Settings,
  Zap,
  Layers,
  AlertTriangle,
  Lightbulb,
  Target,
} from "lucide-react";
import PremiumBackground from "./components/PremiumBackground";
import svgPaths from "./imports/svg-78xtiwj304";
import imgRectangle6 from "figma:asset/6d6df86e2c8fe0dcfbb3f8b3c4a55c8564b130e6.png";
import imgImage2 from "figma:asset/b66683c091f47ee48661fec2c0e1b455be6a833e.png";
import { useState, useEffect } from "react";

export default function App() {
  const targetScore = 70;
  const [displayScore, setDisplayScore] = useState(0);

  // 数字递增动画
  useEffect(() => {
    const duration = 2000; // 2秒
    const steps = 60;
    const increment = targetScore / steps;
    const stepTime = duration / steps;

    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= targetScore) {
        setDisplayScore(targetScore);
        clearInterval(timer);
      } else {
        setDisplayScore(Math.floor(current));
      }
    }, stepTime);

    return () => clearInterval(timer);
  }, []);

  // 根据分数计算颜色
  const getScoreColor = (score: number) => {
    if (score <= 33) {
      // 红色
      return {
        start: "rgba(220, 60, 60, 0.9)",
        end: "rgba(255, 100, 80, 0.7)",
      };
    } else if (score <= 66) {
      // 橙色
      return {
        start: "rgba(255, 140, 60, 0.9)",
        end: "rgba(255, 180, 80, 0.7)",
      };
    } else {
      // 绿色
      return {
        start: "rgba(100, 200, 80, 0.9)",
        end: "rgba(80, 220, 120, 0.7)",
      };
    }
  };

  const scoreColor = getScoreColor(displayScore);

  return (
    <PremiumBackground>
      <div className="size-full overflow-y-auto">
        {/* Navigation */}
        <nav className="px-4 sm:px-8 lg:px-12 xl:px-16 py-4 sm:py-6">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-b from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] rounded-[18px] px-4 py-2 border border-[rgba(100,100,115,0.4)] backdrop-blur-sm">
                <p
                  className="font-black text-[16px] tracking-[0.8px]"
                  style={{
                    color: "#39ff14",
                    textShadow:
                      "0 0 10px rgba(57, 255, 20, 0.8), 0 0 20px rgba(57, 255, 20, 0.5), 0 0 30px rgba(57, 255, 20, 0.3), 0 2px 4px rgba(0, 0, 0, 0.8)",
                    WebkitTextStroke:
                      "0.5px rgba(57, 255, 20, 0.3)",
                  }}
                >
                  WORLD
                </p>
              </div>
              <div className="bg-[rgba(60,60,70,0.6)] rounded-[18px] px-3 py-1 border border-[rgba(100,100,110,0.3)]">
                <p className="text-[#c1c5cc] text-[11px] tracking-[0.55px]">
                  BETA
                </p>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-3 sm:gap-4">
              {/* Language Button */}
              <button className="hidden sm:flex rounded-[14px] px-4 py-2 bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors">
                <span className="text-[#e8e8ec] text-[14px]">
                  简体中文
                </span>
              </button>

              {/* Icon Buttons */}
              <button className="size-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors flex items-center justify-center">
                <Globe className="w-5 h-5 text-[#c1c5cc]" />
              </button>

              <button className="size-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors flex items-center justify-center">
                <User className="w-5 h-5 text-[#c1c5cc]" />
              </button>

              {/* Stats Container */}
              <div className="hidden sm:flex h-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] border border-[rgba(100,100,110,0.3)] px-3 items-center gap-2">
                <Clock className="w-4 h-4 text-[#c1c5cc]" />
                <span className="text-[#e8e8ec] text-[13px]">
                  1,145
                </span>
              </div>

              <button className="size-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors flex items-center justify-center">
                <Share2 className="w-5 h-5 text-[#c1c5cc]" />
              </button>

              <button className="size-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors flex items-center justify-center">
                <Settings className="w-5 h-5 text-[#c1c5cc]" />
              </button>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="px-4 sm:px-8 lg:px-16 py-8 sm:py-12">
          {/* Analysis Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mb-8 sm:mb-12">
            {/* Card 1 - Uniqueness Score - 小卡片 */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="lg:col-span-4 bg-gradient-to-r from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] rounded-2xl border border-[rgba(100,100,115,0.4)] backdrop-blur-sm overflow-hidden"
            >
              <div className="p-5 sm:p-6">
                <div className="flex items-center gap-4">
                  {/* Circular Progress */}
                  <div className="relative w-[120px] h-[120px] flex-shrink-0">
                    <svg className="w-full h-full transform -rotate-90">
                      {/* 背景圆环 - 分段虚线效果 */}
                      <circle
                        cx="50%"
                        cy="50%"
                        r="45%"
                        fill="none"
                        stroke="rgba(100,100,115,0.25)"
                        strokeWidth="14"
                        strokeDasharray="6 3"
                        strokeLinecap="round"
                      />
                      {/* 进度圆环 - 从12点钟方向开始顺时针填充 */}
                      <motion.circle
                        cx="50%"
                        cy="50%"
                        r="45%"
                        fill="none"
                        stroke={`url(#scoreGradient-${displayScore})`}
                        strokeWidth="14"
                        strokeDasharray="6 3"
                        strokeLinecap="round"
                        initial={{ pathLength: 0 }}
                        animate={{
                          pathLength: displayScore / 100,
                        }}
                        transition={{
                          duration: 2,
                          ease: "easeOut",
                        }}
                      />
                      <defs>
                        <linearGradient
                          id={`scoreGradient-${displayScore}`}
                          x1="0%"
                          y1="0%"
                          x2="100%"
                          y2="100%"
                        >
                          <stop
                            offset="0%"
                            stopColor={scoreColor.start}
                          />
                          <stop
                            offset="100%"
                            stopColor={scoreColor.end}
                          />
                        </linearGradient>
                      </defs>
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <motion.span
                        className="text-4xl font-black bg-gradient-to-b from-[#ebebf0] to-[#b4b9c3] bg-clip-text text-transparent"
                        key={displayScore}
                      >
                        {displayScore}
                      </motion.span>
                    </div>
                  </div>

                  {/* Text Content */}
                  <div className="flex-1">
                    <h3 className="text-[#ebebf0] text-xl leading-snug font-semibold mb-3">
                      独特性评分
                    </h3>
                    <div className="flex items-baseline gap-2 mb-2">
                      <motion.span
                        className="text-3xl font-black leading-none bg-gradient-to-b from-[#ebebf0] to-[#b4b9c3] bg-clip-text text-transparent"
                        key={`text-${displayScore}`}
                      >
                        {displayScore}
                      </motion.span>
                      <span className="text-[#7a7a88] text-base leading-none">
                        /100
                      </span>
                      <div className="inline-flex items-center gap-2 bg-[rgba(57,255,20,0.1)] border border-[rgba(57,255,20,0.3)] rounded-lg px-2.5 py-1.5 ml-1">
                        <div
                          className="w-2 h-2 rounded-full"
                          style={{
                            background: "#39ff14",
                            boxShadow:
                              "0 0 8px rgba(57, 255, 20, 0.8)",
                          }}
                        />
                        <span
                          className="text-sm font-semibold leading-tight"
                          style={{
                            color: "#39ff14",
                            textShadow:
                              "0 0 10px rgba(57, 255, 20, 0.5)",
                          }}
                        >
                          独一无二的
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Card 2 - Core Anomaly - 大卡片 */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="lg:col-span-8 bg-gradient-to-r from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] rounded-2xl border border-[rgba(100,100,115,0.4)] backdrop-blur-sm overflow-hidden"
            >
              <div className="p-5 sm:p-6">
                <div className="flex items-start gap-3 mb-4">
                  <Zap className="w-6 h-6 text-[#39ff14] flex-shrink-0" style={{ filter: 'drop-shadow(0 0 8px rgba(57, 255, 20, 0.6))' }} />
                  <div className="flex-1">
                    <h3 className="text-[#ebebf0] text-xl leading-snug font-semibold mb-1">
                      核心异常已识别
                    </h3>
                    <p className="text-[#7a7a88] text-xs leading-normal">
                      Metaphysical Anomaly Detected
                    </p>
                  </div>
                </div>

                {/* 主要异常描述框 */}
                <div className="bg-[rgba(25,25,35,0.6)] rounded-xl px-4 py-3 border border-[rgba(80,80,95,0.3)]">
                  <div className="flex items-center gap-2 mb-3">
                    <div
                      className="w-1 h-4 rounded-full bg-[#39ff14]"
                      style={{
                        boxShadow:
                          "0 0 8px rgba(57, 255, 20, 0.6)",
                      }}
                    />
                    <h4 className="text-[#e8e8ec] text-base leading-normal font-semibold">
                      形而上学异常
                    </h4>
                  </div>
                  <p className="text-[#c1c5cc] text-sm leading-relaxed">
                    该前提通过引入与说谎行为直接相关的超自然、物理后果(阴茎生长)来扰乱形而上学的法则,这从根本上改变了这个世界的现实和因果关系。
                  </p>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Analysis Categories */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mb-8 sm:mb-12"
          >
            <div className="flex items-center gap-3 mb-6">
              <div
                className="w-1 h-8 rounded-full"
                style={{
                  background:
                    "linear-gradient(180deg, #39ff14 0%, rgba(57, 255, 20, 0.3) 100%)",
                  boxShadow: "0 0 10px rgba(57, 255, 20, 0.5)",
                }}
              />
              <h2 className="text-2xl sm:text-3xl font-black tracking-wider bg-gradient-to-b from-[#ebebf0] to-[#b4b9c3] bg-clip-text text-transparent">
                多米诺效应分析
              </h2>
            </div>

            {/* 方向唯一性评估模块 */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.45 }}
              className="mb-6 bg-gradient-to-r from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] rounded-2xl border border-[rgba(100,100,115,0.4)] backdrop-blur-sm p-5 sm:p-6"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                {/* 左侧文字内容 */}
                <div className="flex-1">
                  <h3 className="text-[#ebebf0] text-lg sm:text-xl font-bold mb-2">
                    方向唯一性评估
                  </h3>
                  <p className="text-[#c1c5cc] text-sm sm:text-base leading-relaxed">
                    分析世界设定中的叙事方向限制，评估故事发展的自由度与创作空间的开放程度。
                  </p>
                </div>

                {/* 右侧按钮 */}
                <button className="w-full sm:w-auto h-[48px] rounded-xl px-6 bg-gradient-to-br from-[rgba(100,100,120,0.8)] to-[rgba(80,80,100,0.8)] hover:from-[rgba(120,120,145,0.95)] hover:to-[rgba(100,100,125,0.95)] border border-[rgba(140,140,160,0.5)] hover:border-[rgba(160,160,180,0.7)] transition-all duration-300 flex items-center justify-center gap-2 flex-shrink-0">
                  <span className="text-[#e8e8ec] font-bold text-[14px]">
                    评估方向
                  </span>
                  <ChevronDown className="w-4 h-4 text-[#e8e8ec] transform -rotate-90" />
                </button>
              </div>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                {
                  title: "空间",
                  desc: "设置被限制在一个特定地点(学校),通过物理异常的存在和参数限制了叙可能性",
                  detail:
                    "核心异常仅在学校环境中显现,将行动和角色发展束缚于特定的地理边界。",
                  color: {
                    border: "rgba(100, 150, 255, 0.4)",
                    hoverBorder: "rgba(100, 150, 255, 0.6)",
                    accent: "rgba(100, 150, 255, 0.6)",
                    glow: "0 0 12px rgba(100, 150, 255, 0.3)",
                  },
                },
                {
                  title: "生态",
                  desc: "整个社会和生态系统受核心异常影响,社会互动和动植物生态系统根据叙事核心改变其功能。",
                  detail:
                    "植物无法在世界中正常生长,空气也可能受到影响,凸显核心异常对地球的根本影响。",
                  color: {
                    border: "rgba(100, 200, 120, 0.4)",
                    hoverBorder: "rgba(100, 200, 120, 0.6)",
                    accent: "rgba(100, 200, 120, 0.6)",
                    glow: "0 0 12px rgba(100, 200, 120, 0.3)",
                  },
                },
                {
                  title: "认知",
                  desc: "角色认为说谎导致阴茎增长是正常的,可接受的。引出了对认知失调和道德合理化的深层次探讨。",
                  detail:
                    "通过把不正常变成常态,这种认知转变引发了关于文化规范和道结构的质疑。",
                  color: {
                    border: "rgba(180, 120, 255, 0.4)",
                    hoverBorder: "rgba(180, 120, 255, 0.6)",
                    accent: "rgba(180, 120, 255, 0.6)",
                    glow: "0 0 12px rgba(180, 120, 255, 0.3)",
                  },
                },
                {
                  title: "机制",
                  desc: "事件受核心异常中给定的规则和机制控制。核心主要是固定的,无法被重写或改变。",
                  detail:
                    "设定围绕前提的不变规则运作,意味着变化需要在不改变核心规则的前提下围绕它进行。",
                  color: {
                    border: "rgba(255, 160, 100, 0.4)",
                    hoverBorder: "rgba(255, 160, 100, 0.6)",
                    accent: "rgba(255, 160, 100, 0.6)",
                    glow: "0 0 12px rgba(255, 160, 100, 0.3)",
                  },
                },
                {
                  title: "时间",
                  desc: "异常的核心是一个固定的前提,形式也不会随着时间的推移而变化,维持一致的核心。",
                  detail:
                    "世界的根本概念是静态的,但它可能在特定时间点被启动,推动形式化的发展。",
                  color: {
                    border: "rgba(100, 200, 200, 0.4)",
                    hoverBorder: "rgba(100, 200, 200, 0.6)",
                    accent: "rgba(100, 200, 200, 0.6)",
                    glow: "0 0 12px rgba(100, 200, 200, 0.3)",
                  },
                },
                {
                  title: "动力",
                  desc: "异常的核心固定,作为驱动因素,叙述从该前提点发展,主导进程和可选择方向的空间。",
                  detail:
                    "围绕世界的所有行为由核心前提驱动,为叙事的发展提供不可改变的方向。",
                  color: {
                    border: "rgba(255, 120, 120, 0.4)",
                    hoverBorder: "rgba(255, 120, 120, 0.6)",
                    accent: "rgba(255, 120, 120, 0.6)",
                    glow: "0 0 12px rgba(255, 120, 120, 0.3)",
                  },
                },
                {
                  title: "形而上学",
                  desc: "该前提从根本上重构了现实的本质法则,建立了一个谎言与物质直接关联的超自然因果系统。",
                  detail:
                    "通过将抽象概念(谎言)与具体物理变化(身体生长)绑定,世界的形而上学结构被彻底改写,挑战了真实与虚构的边界。",
                  color: {
                    border: "rgba(255, 220, 100, 0.4)",
                    hoverBorder: "rgba(255, 220, 100, 0.6)",
                    accent: "rgba(255, 220, 100, 0.6)",
                    glow: "0 0 12px rgba(255, 220, 100, 0.3)",
                  },
                },
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.6,
                    delay: 0.5 + index * 0.1,
                  }}
                  className="bg-gradient-to-br from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] rounded-2xl backdrop-blur-sm p-6 transition-all duration-300 relative overflow-hidden group"
                  style={{
                    border: `1px solid ${item.color.border}`,
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = item.color.hoverBorder;
                    e.currentTarget.style.boxShadow = item.color.glow;
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = item.color.border;
                    e.currentTarget.style.boxShadow = 'none';
                  }}
                >
                  
                  <h3 className="text-[#e8e8ec] text-xl leading-snug font-semibold mb-4 flex items-center gap-3">
                    <div 
                      className="w-2 h-2 rounded-full flex-shrink-0"
                      style={{
                        background: item.color.accent,
                        boxShadow: item.color.glow,
                      }}
                    />
                    {item.title}
                  </h3>
                  <p className="text-[#c1c5cc] text-sm leading-relaxed mb-4">
                    {item.desc}
                  </p>
                  <div 
                    className="pl-4 border-l-2"
                    style={{
                      borderColor: item.color.accent,
                    }}
                  >
                    <p className="text-[#7a7a88] text-xs leading-relaxed italic">
                      {item.detail}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Additional Analysis Sections */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1.2 }}
            className="space-y-6"
          >
            {/* Premise Analysis */}
            <div className="bg-gradient-to-r from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] rounded-2xl border border-[rgba(100,100,115,0.4)] backdrop-blur-sm p-6 sm:p-8">
              {/* 标题区域 */}
              <div className="flex items-center gap-3 mb-4">
                <Layers className="w-6 h-6 text-[#39ff14] flex-shrink-0" style={{ filter: 'drop-shadow(0 0 8px rgba(57, 255, 20, 0.6))' }} />
                <h3 className="text-[#ebebf0] text-xl sm:text-2xl font-bold">
                  橡皮擦测试
                </h3>
              </div>

              {/* 副标题 */}
              <p className="text-[#7a7a88] text-sm mb-4">
                应用于非目标点
              </p>

              {/* 主要描述 */}
              <p className="text-[#c1c5cc] text-sm sm:text-base leading-relaxed mb-6">
                在菊状仪式中，主持人通称为"入经验者,从而瞬间改变持推涉家和舍会论汰,使这二事实成为真实,若蒂打没强应置者但说谎测试掉落为口马宜者的新视头。
              </p>

              {/* 对话框1 */}
              <div className="bg-[rgba(25,25,35,0.6)] rounded-xl p-4 border border-[rgba(80,80,95,0.3)] mb-4">
                <p className="text-[#7a7a88] text-xs mb-2">
                  在《从人世界》中提及同样的情况:
                </p>
                <p className="text-[#c1c5cc] text-sm leading-relaxed">
                  在正常世界里，主持人会诚称新人已经结婚，但这并没有影响;需使实际联系排地也能实际成双没有提行。
                </p>
              </div>

              {/* 对话框2 */}
              <div className="bg-[rgba(25,25,35,0.6)] rounded-xl p-4 border border-[rgba(80,80,95,0.3)] mb-4">
                <p className="text-[#7a7a88] text-xs mb-2">
                  对照:
                </p>
                <p className="text-[#c1c5cc] text-sm leading-relaxed">
                  没有核心通州德，调查只是展夏顾试，无法改变现实，在国属申，它自接表复于和法律，使同骨本质曾孕而非虚构。
                </p>
              </div>

              {/* 结构部分 */}
              <div className="flex items-center gap-2 mb-3">
                <div
                  className="w-1.5 h-1.5 rounded-full bg-[#39ff14]"
                  style={{
                    boxShadow: "0 0 6px rgba(57, 255, 20, 0.6)",
                  }}
                />
                <span className="text-[#e8e8ec] text-sm font-bold">
                  结构:
                </span>
              </div>

              <p className="text-[#c1c5cc] text-sm leading-relaxed mb-5 pl-4">
                在将文化元素融入一位主角的叙事时,主体通过继承制度或背景的融合间接展现归属(或他者化)。该设定的核心源于在特定地点(学校)中建立的固定前提,成为故事展开的基础。
              </p>

              {/* 底部按钮 */}
              <div className="flex justify-start">
                <button
                  className="h-[36px] rounded-xl px-5 flex items-center gap-2 transition-all duration-300"
                  style={{
                    background: "rgba(57, 255, 20, 0.1)",
                    border: "1px solid rgba(57, 255, 20, 0.3)",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background =
                      "rgba(57, 255, 20, 0.15)";
                    e.currentTarget.style.borderColor =
                      "rgba(57, 255, 20, 0.5)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background =
                      "rgba(57, 255, 20, 0.1)";
                    e.currentTarget.style.borderColor =
                      "rgba(57, 255, 20, 0.3)";
                  }}
                >
                  <div
                    className="w-5 h-5 rounded-full border-2 flex items-center justify-center"
                    style={{
                      borderColor: "#39ff14",
                    }}
                  >
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{
                        background: "#39ff14",
                        boxShadow:
                          "0 0 6px rgba(57, 255, 20, 0.8)",
                      }}
                    />
                  </div>
                  <span
                    className="text-sm font-bold"
                    style={{
                      color: "#39ff14",
                      textShadow:
                        "0 0 8px rgba(57, 255, 20, 0.4)",
                    }}
                  >
                    结构
                  </span>
                </button>
              </div>
            </div>

            {/* Warning Section */}
            <div className="bg-gradient-to-br from-[rgba(100,60,40,0.15)] to-[rgba(80,50,30,0.15)] rounded-2xl border border-[rgba(200,150,100,0.3)] backdrop-blur-sm p-5">
              <div className="flex items-center gap-3 mb-4">
                <AlertTriangle className="w-6 h-6 text-[#ffb464] flex-shrink-0" style={{ filter: 'drop-shadow(0 0 6px rgba(255, 180, 100, 0.4))' }} />
                <h3 className="text-[#ffb464] text-lg sm:text-xl font-bold">
                  潜在问题
                </h3>
              </div>
              <ul className="space-y-2.5">
                <li className="flex items-start gap-2.5 text-[#c1c5cc] text-sm leading-relaxed hover:text-[#d5d9e0] transition-colors">
                  <span className="text-[#ffb464] mt-0.5 flex-shrink-0">●</span>
                  <span>高复杂性、不连贯性的固定前提(核心),在叙述过程中可能导致严格限制的世界结构以及角色灵活性与创意深度的缺失。</span>
                </li>
                <li className="flex items-start gap-2.5 text-[#c1c5cc] text-sm leading-relaxed hover:text-[#d5d9e0] transition-colors">
                  <span className="text-[#ffb464] mt-0.5 flex-shrink-0">●</span>
                  <span>如果叙述没有充分探索道德含义或者聚焦于情节营造感,它可能被简化成荒谬的噱头。</span>
                </li>
                <li className="flex items-start gap-2.5 text-[#c1c5cc] text-sm leading-relaxed hover:text-[#d5d9e0] transition-colors">
                  <span className="text-[#ffb464] mt-0.5 flex-shrink-0">●</span>
                  <span>故事强调了身体怪异化或荒谬的身体特征,如果处理不当可能导致不敏感的刻画。</span>
                </li>
              </ul>
            </div>

            {/* Recommendations */}
            <div className="bg-gradient-to-br from-[rgba(40,80,120,0.15)] to-[rgba(30,60,100,0.15)] rounded-2xl border border-[rgba(100,150,200,0.3)] backdrop-blur-sm p-5">
              <div className="flex items-center gap-3 mb-4">
                <Lightbulb className="w-6 h-6 text-[#8ec5ff] flex-shrink-0" style={{ filter: 'drop-shadow(0 0 6px rgba(142, 197, 255, 0.4))' }} />
                <h3 className="text-[#8ec5ff] text-lg sm:text-xl font-bold">
                  推荐
                </h3>
              </div>
              <ul className="space-y-2.5">
                <li className="flex items-start gap-2.5 text-[#c1c5cc] text-sm leading-relaxed hover:text-[#d5d9e0] transition-colors">
                  <span className="text-[#8ec5ff] mt-0.5 flex-shrink-0">○</span>
                  <span>使用该怪异的前提建立更复杂的社会动态(舆论、社会阶层、集体价值),利于更深入文化与社会上的叙事。</span>
                </li>
                <li className="flex items-start gap-2.5 text-[#c1c5cc] text-sm leading-relaxed hover:text-[#d5d9e0] transition-colors">
                  <span className="text-[#8ec5ff] mt-0.5 flex-shrink-0">○</span>
                  <span>探索学校环境中的权力动态和层次化结构,以及相比于受限制的社会,在这个荒唐但固定的前提下社会系统如何重新校准。</span>
                </li>
                <li className="flex items-start gap-2.5 text-[#c1c5cc] text-sm leading-relaxed hover:text-[#d5d9e0] transition-colors">
                  <span className="text-[#8ec5ff] mt-0.5 flex-shrink-0">○</span>
                  <span>理解一个支持主人公的道德或哲学框架,或主人公在这个前提下必须面对的伦理困境,而不是仅仅停留表面怪异。</span>
                </li>
              </ul>
            </div>
          </motion.div>

          {/* Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1.4 }}
            className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <button
              className="w-full sm:w-auto h-[48px] rounded-xl px-8 flex items-center justify-center gap-3 transition-all duration-300 group"
              style={{
                background:
                  "linear-gradient(135deg, #39ff14 0%, #2dd60f 100%)",
                boxShadow:
                  "0 0 20px rgba(57, 255, 20, 0.4), 0 4px 12px rgba(0, 0, 0, 0.3)",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow =
                  "0 0 30px rgba(57, 255, 20, 0.6), 0 6px 16px rgba(0, 0, 0, 0.4)";
                e.currentTarget.style.transform =
                  "translateY(-2px)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow =
                  "0 0 20px rgba(57, 255, 20, 0.4), 0 4px 12px rgba(0, 0, 0, 0.3)";
                e.currentTarget.style.transform =
                  "translateY(0)";
              }}
            >
              <svg
                className="w-5 h-5 text-black"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M13 10V3L4 14h7v7l9-11h-7z"
                />
              </svg>
              <span className="text-black font-bold text-[14px] sm:text-[15px]">
                核心异常艺术大师
              </span>
            </button>

            <button className="w-full sm:w-auto h-[48px] rounded-xl px-8 bg-gradient-to-br from-[rgba(100,100,120,0.8)] to-[rgba(80,80,100,0.8)] hover:from-[rgba(120,120,145,0.95)] hover:to-[rgba(100,100,125,0.95)] border border-[rgba(140,140,160,0.5)] hover:border-[rgba(160,160,180,0.7)] transition-all duration-300 flex items-center justify-center gap-3">
              <ChevronDown className="w-5 h-5 text-[#e8e8ec]" />
              <span className="text-[#e8e8ec] font-bold text-[14px] sm:text-[15px]">
                跳转至高级分析阶段
              </span>
            </button>
          </motion.div>
        </main>
      </div>
    </PremiumBackground>
  );
}