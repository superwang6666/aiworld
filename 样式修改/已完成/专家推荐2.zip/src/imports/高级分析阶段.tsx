import svgPaths from "./svg-e1lkeh13n8";
import img33333331 from "figma:asset/a70b84b89df2a4ba2dadc259ec9cd09f251f88db.png";
import img444441 from "figma:asset/f9ebd680fd364713cba6c22f8258cf4df405dc6f.png";

function MainContent() {
  return (
    <div className="absolute content-stretch flex flex-col h-[2137px] items-center left-0 overflow-clip pt-[72px] px-[255px] top-[90px] w-[1534px]" data-name="Main Content">
      <div className="h-[370px] relative shrink-0 w-[1472px]" data-name="3333333 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={img33333331} />
      </div>
      <div className="h-[1647px] relative shrink-0 w-[1472px]" data-name="44444 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[108.67%] left-[-3.64%] max-w-none top-[-0.02%] w-[107.29%]" src={img444441} />
        </div>
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="flex-[1_0_0] h-[24px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Arial:Black',sans-serif] leading-[24px] left-0 not-italic text-[#39ff14] text-[16px] top-[2px] tracking-[0.8px]">WORLD</p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="bg-gradient-to-b flex-[1_0_0] from-[rgba(35,35,45,0.9)] h-[42px] min-h-px min-w-px relative rounded-[18px] to-[rgba(45,45,55,0.9)]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,115,0.4)] border-solid inset-0 pointer-events-none rounded-[18px]" />
      <div className="flex flex-row items-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center px-[17px] py-px relative size-full">
          <Text />
        </div>
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="content-stretch flex h-[14px] items-start relative shrink-0 w-full" data-name="Text">
      <p className="font-['Arial:Regular',sans-serif] leading-[16.5px] not-italic relative shrink-0 text-[#c1c5cc] text-[11px] tracking-[0.55px]">BETA</p>
    </div>
  );
}

function Container2() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] h-[34px] relative rounded-[18px] shrink-0 w-[54.328px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[18px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-px pt-[12px] px-[13px] relative size-full">
        <Text1 />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="h-[42px] relative shrink-0 w-[167.234px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container1 />
        <Container2 />
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] flex-[1_0_0] h-[39px] min-h-px min-w-px relative rounded-[14px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[17px] py-[9px] relative size-full">
        <p className="font-['Arial:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] leading-[21px] relative shrink-0 text-[#e8e8ec] text-[14px] text-center" style={{ fontVariationSettings: "'wght' 400" }}>
          简体中文
        </p>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_55)" id="Icon">
          <path d={svgPaths.p2b260000} id="Vector" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_55">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] relative rounded-[12px] shrink-0 size-[36px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-px relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p1d939600} id="Vector" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p5272800} id="Vector_2" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] relative rounded-[12px] shrink-0 size-[36px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-px relative size-full">
        <Icon1 />
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_1_58)" id="Icon">
          <path d={svgPaths.p3a6156f0} id="Vector" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p11fb83c0} id="Vector_2" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M4.66667 4H5.33333V6.66667" id="Vector_3" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p583e380} id="Vector_4" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_1_58">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text2() {
  return (
    <div className="flex-[1_0_0] h-[19.5px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Arial:Regular',sans-serif] leading-[19.5px] left-0 not-italic text-[#e8e8ec] text-[13px] top-[-1px]">1,145</p>
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] h-[33.5px] relative rounded-[12px] shrink-0 w-[83.625px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center px-[13px] py-px relative size-full">
        <Icon2 />
        <Text2 />
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p1beb9580} id="Vector" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p32ab0300} id="Vector_2" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] relative rounded-[12px] shrink-0 size-[36px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-px relative size-full">
        <Icon3 />
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p654be80} id="Vector" stroke="var(--stroke-0, #C1C5CC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] relative rounded-[12px] shrink-0 size-[36px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-px relative size-full">
        <Icon4 />
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="h-[39px] relative shrink-0 w-[377.625px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Button />
        <Button1 />
        <Button2 />
        <Container4 />
        <Button3 />
        <Button4 />
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="absolute content-stretch flex h-[90px] items-center justify-between left-0 px-[64px] top-0 w-[1534px]" data-name="Navigation">
      <Container />
      <Container3 />
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-[#0f0f14] relative size-full" data-name="高级分析阶段">
      <MainContent />
      <Navigation />
    </div>
  );
}