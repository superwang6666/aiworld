import PremiumBackground from "./components/PremiumBackground";
import svgPaths from "./imports/svg-e1lkeh13n8";
import { motion } from "motion/react";
import { useState } from "react";
import { 
  User, 
  Globe, 
  Mountain, 
  BookOpen, 
  MessageSquare, 
  Shield, 
  Star, 
  AlertTriangle, 
  Lightbulb, 
  Sparkles, 
  Users, 
  Atom, 
  RefreshCw, 
  Scale, 
  Gem,
  TrendingUp,
  AlertCircle,
  ArrowLeft
} from "lucide-react";

function MainContent() {
  const [expandedExperts, setExpandedExperts] = useState<
    Set<number>
  >(new Set());

  // 法则权柄数据
  const lawCategories = [
    {
      name: "形而上学",
      percentage: 25.7,
      color: "from-yellow-400 to-yellow-600",
      borderColor: "rgba(255, 220, 100, 0.5)",
      rules: 8,
    },
    {
      name: "空间",
      percentage: 18.3,
      color: "from-blue-400 to-blue-600",
      borderColor: "rgba(100, 150, 255, 0.4)",
      rules: 6,
    },
    {
      name: "生态",
      percentage: 16.8,
      color: "from-green-400 to-green-600",
      borderColor: "rgba(100, 200, 120, 0.4)",
      rules: 5,
    },
    {
      name: "认知",
      percentage: 14.2,
      color: "from-purple-400 to-purple-600",
      borderColor: "rgba(180, 120, 255, 0.4)",
      rules: 5,
    },
    {
      name: "机制",
      percentage: 12.5,
      color: "from-orange-400 to-orange-600",
      borderColor: "rgba(255, 160, 100, 0.4)",
      rules: 4,
    },
    {
      name: "时间",
      percentage: 9.8,
      color: "from-cyan-400 to-cyan-600",
      borderColor: "rgba(100, 200, 200, 0.4)",
      rules: 3,
    },
    {
      name: "动力",
      percentage: 2.7,
      color: "from-red-400 to-red-600",
      borderColor: "rgba(255, 120, 120, 0.4)",
      rules: 2,
    },
  ];

  // 专家委员会数据
  const experts = [
    {
      name: "卡尔图拉·索西亚博士",
      field: "人类学与社会学",
      icon: User,
      iconColor: "#7dd3fc",
      opinion:
        "从人类学与社会学角度看，这个核心异质点创造了一个基于言语真实性的宇宙论框架。文化世界观将彻底重构：谎言不再只是道德问题，而是直接威胁物理世界存续的灾难性行为。社会将发展出复杂的言语监控系统，因为每句谎言都可能引发环境灾难。价值系统会围绕'言语纯洁性'重新组织，诚实成为最高美德，而任何形式的欺骗（无论善意与否）都被视为社会公敌。 社会阶层和权力关系将发生根本性转变。掌握'真相验证'技术的群体（如言语分析师、记忆读取者）将成为新的精英阶层。社会可能发展出严格的言语等级制度，基于个人历史中谎言的数量和严重性划分社会地位。权力不再来自财富或武力，而是来自言语的可信度和验证能力。社会控制机制会高度集中在对言语的监控和规范上，形成一种'言语极权主义'社会结构。",
      warning:
        "社会可能发展出病态的诚实文化，导致情感表达和社会润滑机制完全崩溃",
      suggestion:
        "研究发展非侵入性的谎言检测技术，平衡安全需求与个人隐私",
    },
    {
      name: "弗洛·艾科诺博士",
      field: "经济学",
      icon: TrendingUp,
      iconColor: "#fbbf24",
      opinion:
        "从经济学角度看，这个异质点将谎言从纯粹的社会行为转变为具有直接物理后果的生产要素，彻底重构了经济系统的基础。当谎言导致世界变成淹没之国时，真实信息成为最稀缺的资源，因为任何虚假陈述都会引发灾难性的环境变化。这创造了一种前所未有的负外部性：说谎的成本从社会惩罚变为物理毁灭，导致经济激励完全转向真实性验证和风险规避。 在这种新现实中，经济价值体系发生根本性转变。防淹技术、真实性验证工具和灾难恢复服务成为最有价值的商品，而依赖信任的传统交易模式面临崩溃。市场结构必须重组以适应极高的信息不对称成本，因为任何交易中的虚假陈述都可能引发局部淹没。经济增长不再取决于传统生产要素的积累，而是取决于社会如何最小化谎言产出和最大化真实信息流动的效率。",
      warning:
        "经济系统可能因过度风险规避而陷入停滞，创新活动因害怕意外谎言后果而受到抑制",
      suggestion:
        "建立分层的真实性保险市场，允许可控风险下的经济实验和创新",
    },
    {
      name: "泰拉·格奥教授",
      field: "地质学与气候学",
      icon: Globe,
      iconColor: "#34d399",
      opinion:
        "从地质与气候学角度分析，这个异质点将人类言语行为（谎话）与全球性物理变化（淹没之国）直接关联，构成了一个非线性的因果系统。地质构造方面，谎话可能触发或加速板块运动，导致地壳下沉或海平面相对上升，形成淹没地貌。例如，谎话可能通过未知机制增加地壳负荷或降低地壳浮力，引发区域性沉降，同时伴随火山活动减少（因压力释放异常），使陆地逐渐被海水覆盖。气候系统会响应这种变化，大气循环因海洋面积扩大而增强，导致降水模式向极端化发展——更多暴雨集中在剩余陆地区域，而温度分布因海洋热容量增加而趋于平缓，减少季节性温差，但可能加剧热带气旋频率。 对生存环境的影响是毁灭性的：水资源总量增加但多为咸水，淡水稀缺加剧；土壤肥力因淹没和盐碱化而丧失，陆地生态系统崩溃；自然灾害频率显著上升，包括海啸、风暴潮和洪水，但地震和火山活动可能因地质应力异常释放而减少。矿产资源分布变得难以获取，陆基矿藏被淹没，海洋资源开采因环境不稳定而高风险。长期地质演化趋势指向一个完全海洋化的星球，陆地消失，生物圈依赖海洋生态系统,但谎话的持续影响可能导致周期性海平面波动，形成动态淹没景观。 物理基础限制在于，这种异质点违背了传统地球物理学的能量守恒和因果律，谎话作为低能量输入却能驱动大规模地质变化，暗示存在超自然或高维机制。这启用了世界构建的可能性，如社会规范（如禁谎）成为生存关键，地质灾难可预测但不可控，气候模型需整合言语变量。然而，必须设定阈值或反馈机制以避免逻辑悖论，例如谎话的累积效应或真实性定义影响淹没速率。",
      warning:
        "异质点可能使物理系统不稳定，若无约束机制（如谎话阈值或抵消因素），世界可能迅速完全淹没，失去叙事张力。",
      suggestion:
        "引入反谎话机制（如真话能减缓淹没或重建陆地）以平衡系统，增加策略深度。",
    },
    {
      name: "克罗诺·阿尔凯教授",
      field: "历史学与考古学",
      icon: BookOpen,
      iconColor: "#a78bfa",
      opinion:
        "从历史学与考古学角度分析，这个异质点将彻底改写人类文明的发展轨迹。谎话与物理世界淹没的直接因果关系意味着言语行为具有了地质改造能力，这将在历史进程中创造一种前所未有的社会控制机制。早期文明会发展出高度仪式化的言语规范体系，任何社会不稳定或权力更迭都可能通过谎言的积累效应引发区域性淹没事件，导致文明中心频繁迁移。考古记录将显示人类聚落呈现出明显的'避水模式'——遗址多位于高海拔地区或人工建造的巨型平台之上，而低洼地区则成为被周期性淹没的'言语禁忌区'。 历史记忆和集体认知将围绕'言语真实性'构建核心社会契约。口述传统会极度强调精确记忆和事实验证，任何历史叙事都潜在的淹没风险而被严格审查。物质文化中会出现大量用于检测和记录真实性的工具——从早期的誓言石到复杂的言语记录装置，这些文物将成为考古遗址中最常见的遗存。技术发展将严重偏向于防洪、水上生存和言语控制技术，而传统意义上的科学探索可能因'危险的知识传播'而受到抑制。历史周将不再遵循传统的兴衰模式是呈现'言语积累-淹没-重建'的循环，文明持续时间直接取决于社会维持真实性的能力。",
      warning:
        "考古发掘需极端谨慎——任何对古代谎言的重新激活都可能引发当代淹没风险",
      suggestion:
        "开发非侵入式考古技术，通过遥感探测淹没文明遗迹",
    },
    {
      name: "林古瓦·沃克斯教授",
      field: "语言学",
      icon: MessageSquare,
      iconColor: "#fb923c",
      opinion:
        "从语言学角度看，这个异质点将语言行为（说谎）与物理现实（世界变成淹没之国）直接关联，创造了语言-现实因果律。这会从根本上重塑语言结构：语音统可能发展出特殊的'真言音素'或'谎言检测音调'，语法会强制要求真实性标记（如强制性真值后缀），词汇会大量涌现描述谎言后果、洪水状态和诚实验证的术语。语言不再只是交流工具，而是具有直接物理后果的行为系统。 新的交流需求会催生三类主要词汇：1）谎言检测与分类词汇（如'微谎''恶谎''生存谎'等分级术语）；2）洪水相关术语（描述不同淹没程度、水质状态、生存策略）；3）真言强化表达（如仪式性诚实誓言、事实确认公式）。语言权力关系将剧烈变化：掌握'真言技术'的群体（如能精确描述现实而不引发灾难的专家）将成为主导，而传统政治修辞广告语言等可能被严格管制或消亡。书写系统需要发展出视觉化的真值标记（如特殊墨水变色显示谎言、符号周围的'水波纹'警示边框），符号学将关注符号与现实的直接对应关系。 认知效应上，这个异质点会迫使人们发展出'超现实主义思维'：每个陈述都需预判其物理后果，导致普遍的语言焦虑和认知负荷增加。隐喻和模糊表达可能被视为危险，推动思维向极端精确化发展，但同时可能催生复杂的'规避编码系统'（如用技术性真话暗示虚假信息）。语言作为权力工具的作用被放大——控制语言等于控制环境，而作为认知框架，它重塑了人们对真实、责任和因果的基本理解。",
      warning:
        "语言管制可能极端化，导致言论自由完全消失，任何非精确陈述都可能被指控为'潜在谎言'而受惩罚。",
      suggestion:
        "发展'安全隐喻库'：允许在严格限定的非字面语境中使用比喻，而不触发洪水效应。",
    },
    {
      name: "斯特拉特吉·波利斯将军",
      field: "政治学与军事学",
      icon: Shield,
      iconColor: "#f87171",
      opinion:
        "从政治学与军事学角度分析，这个异质点彻底重构了权力运作的基础逻辑。当谎言直接导致物理世界的淹没效应时，信息控制成为生存与统治的核心。政治制度必须围绕'真相强制'机制构建——任何治理结构都需要建立严格的言论监控与验证体系，因为一句谎言可能引发区域性甚至全球性水灾。这催生了极权化的'真相政权'，通过技术手段实时检测谎言并立即干预，政治合法性不再基于意识形态或经济表现，而是基于防止淹没的能力。治理结构将高度中央集权，因为分散的决策风险过大，地方性谎言可能连锁反应导致国家沉没。 军事战略同样发生根本性转变。传统武器系统让位于'信息战防御体系'，军事力量的核心任务是防止敌方或内部人员散布谎言。战术重点从领土占领转向'认知空间控制'，通过心理战、宣传战确保己方叙事绝对主导。战争形态演变为'预防性真相冲突'，先发制人地消除潜在谎言源成为关键战略。地缘政治中，领土控制的意义发生变化——高海拔地区或防洪基础设施完善的区域成为战略要地，而低洼地区可能因谎言风险被主动放弃或严格隔离。",
      warning:
        "极权化风险极高，真相政权可能滥用监控系统镇压异见，导致人性与自由彻底丧失。",
      suggestion:
        "建立国际真相核查与应急机制，通过多边协议共享谎言预警数据，协调防洪资源。",
    },
  ];

  const toggleExpert = (index: number) => {
    const newExpanded = new Set(expandedExperts);
    if (newExpanded.has(index)) {
      newExpanded.delete(index);
    } else {
      newExpanded.add(index);
    }
    setExpandedExperts(newExpanded);
  };

  return (
    <div className="flex flex-col items-center w-full px-4 sm:px-8 lg:px-16 pt-[90px] sm:pt-[110px] pb-8 sm:pb-12 gap-8 sm:gap-12">
      {/* 法则权柄分析模块 */}
      <div className="w-full max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-[28px] sm:text-[32px] mb-8 font-bold bg-gradient-to-r from-[#ebebf0] to-[#b4b9c3] bg-clip-text text-transparent leading-tight">
            法则权柄分析
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {lawCategories.map((category, index) => (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.5,
                  delay: index * 0.08,
                }}
                className="bg-gradient-to-r from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] rounded-2xl p-5 border-2 backdrop-blur-sm hover:shadow-lg transition-all duration-300"
                style={{
                  borderColor:
                    category.borderColor ||
                    "rgba(100,100,115,0.4)",
                }}
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-[#e8e8ec] text-[15px] font-semibold leading-snug">
                    {category.name}
                  </h3>
                  <span className="text-[#c1c5cc] text-[18px] font-bold">
                    {category.percentage}%
                  </span>
                </div>

                {/* 进度条 */}
                <div className="relative w-full h-2 bg-[rgba(25,25,35,0.6)] rounded-full overflow-hidden mb-4">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{
                      width: `${category.percentage}%`,
                    }}
                    transition={{
                      duration: 1,
                      delay: index * 0.08 + 0.3,
                      ease: "easeOut",
                    }}
                    className={`absolute left-0 top-0 h-full bg-gradient-to-r ${category.color} rounded-full`}
                  />
                </div>

                <p className="text-[#7a7a88] text-[13px] leading-normal">
                  {category.rules} 条规则
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* 专家委员会洞察模块 */}
      <div className="w-full max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-[28px] sm:text-[32px] font-bold bg-gradient-to-r from-[#ebebf0] to-[#b4b9c3] bg-clip-text text-transparent leading-tight">
              专家委员会洞察
            </h2>
            <div className="flex items-center gap-2 bg-gradient-to-r from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] px-4 py-2 rounded-xl border border-[rgba(100,100,115,0.4)]">
              <div
                className="w-2 h-2 rounded-full bg-[#39ff14] animate-pulse"
                style={{
                  boxShadow: "0 0 8px rgba(57, 255, 20, 0.8)",
                }}
              />
              <span className="text-[#c1c5cc] text-[13px] font-medium">
                {experts.length} 位专家
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6">
            {experts.map((expert, index) => (
              <motion.div
                key={expert.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.5,
                  delay: index * 0.1,
                }}
                className="group bg-gradient-to-br from-[rgba(35,35,45,0.95)] to-[rgba(45,45,55,0.95)] rounded-2xl border border-[rgba(100,100,115,0.4)] backdrop-blur-sm hover:border-[rgba(57,255,20,0.3)] hover:shadow-[0_0_30px_rgba(57,255,20,0.1)] transition-all duration-500 overflow-hidden"
              >
                {/* 专家信息头部 */}
                <div className="p-6 border-b border-[rgba(100,100,115,0.25)]">
                  <div className="flex items-start gap-5">
                    <div className="relative flex items-center justify-center">
                      <expert.icon 
                        className="w-12 h-12 group-hover:scale-110 transition-transform duration-500" 
                        style={{ color: expert.iconColor }}
                        strokeWidth={1.5}
                      />
                      <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-[#39ff14] rounded-full flex items-center justify-center" style={{
                        boxShadow: '0 0 8px rgba(57, 255, 20, 0.6)'
                      }}>
                        <svg
                          className="w-2.5 h-2.5 text-[#0f0f14]"
                          fill="none"
                          viewBox="0 0 12 12"
                        >
                          <path
                            d="M10 3L4.5 8.5L2 6"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </div>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-[#ebebf0] text-xl font-bold mb-2 group-hover:text-[#39ff14] transition-colors duration-300">
                        {expert.name}
                      </h3>
                      <div className="flex items-center gap-2">
                        <p className="text-[#7a7a88] text-sm font-medium px-3 py-1 bg-[rgba(25,25,35,0.6)] rounded-lg border border-[rgba(80,80,95,0.3)]">
                          {expert.field}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 意见内容 */}
                <div className="p-6 space-y-4">
                  {/* 专业意见 */}
                  <div className="relative">
                    <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-[#39ff14] via-[rgba(57,255,20,0.5)] to-transparent rounded-full" />
                    <div className="pl-6 pr-4 py-4 bg-[rgba(25,25,35,0.5)] rounded-xl border border-[rgba(80,80,95,0.25)]">
                      <div className="flex items-center gap-2 mb-3">
                        <svg
                          className="w-4 h-4 text-[#39ff14]"
                          fill="none"
                          viewBox="0 0 16 16"
                        >
                          <path
                            d="M8 1L10.5 6L16 7L12 11L13 16.5L8 13.5L3 16.5L4 11L0 7L5.5 6L8 1Z"
                            stroke="currentColor"
                            strokeWidth="1.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                        <span className="text-[#39ff14] text-xs font-bold tracking-wider uppercase">
                          专业意见
                        </span>
                      </div>
                      <p
                        className={`text-[#c1c5cc] text-sm leading-loose ${!expandedExperts.has(index) ? "line-clamp-3" : ""}`}
                      >
                        {expert.opinion}
                      </p>
                      {expert.opinion.length > 150 && (
                        <button
                          onClick={() => toggleExpert(index)}
                          className="mt-4 flex items-center gap-2 text-[#39ff14] text-xs font-medium hover:text-[#50ff30] transition-all duration-300 group/btn"
                        >
                          <span>
                            {expandedExperts.has(index)
                              ? "收起内容"
                              : "展开全文"}
                          </span>
                          <svg
                            className={`w-4 h-4 transition-transform duration-300 ${expandedExperts.has(index) ? "rotate-180" : ""} group-hover/btn:translate-y-0.5`}
                            fill="none"
                            viewBox="0 0 16 16"
                          >
                            <path
                              d="M4 6L8 10L12 6"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            />
                          </svg>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* 警告与建议 - 两栏布局 */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* 警告 */}
                    <div className="relative group/warning bg-gradient-to-br from-[rgba(180,80,60,0.12)] to-[rgba(150,60,40,0.08)] rounded-xl p-5 border border-[rgba(180,80,60,0.35)] hover:border-[rgba(180,80,60,0.5)] transition-all duration-300">
                      <div className="flex items-start gap-3">
                        <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5 group-hover/warning:scale-110 transition-transform duration-300" strokeWidth={2} />
                        <div className="flex-1">
                          <p className="text-red-300 text-xs font-bold tracking-widest uppercase mb-2">
                            风险警告
                          </p>
                          <p className="text-[#c1c5cc] text-sm leading-relaxed">
                            {expert.warning}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* 建议 */}
                    <div className="relative group/suggestion bg-gradient-to-br from-[rgba(57,255,20,0.12)] to-[rgba(57,255,20,0.06)] rounded-xl p-5 border border-[rgba(57,255,20,0.35)] hover:border-[rgba(57,255,20,0.5)] transition-all duration-300">
                      <div className="flex items-start gap-3">
                        <Lightbulb className="w-5 h-5 text-[#39ff14] flex-shrink-0 mt-0.5 group-hover/suggestion:scale-110 transition-transform duration-300" strokeWidth={2} />
                        <div className="flex-1">
                          <p className="text-[#39ff14] text-xs font-bold tracking-widest uppercase mb-2">
                            行动建议
                          </p>
                          <p className="text-[#c1c5cc] text-sm leading-relaxed">
                            {expert.suggestion}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* 综合分析模块 */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.6 }}
        className="w-full max-w-6xl"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-[#ebebf0] text-2xl sm:text-3xl font-bold bg-gradient-to-r from-[#ebebf0] to-[#b4b9c3] bg-clip-text text-transparent">
            综合分析
          </h2>
          <div className="flex items-center gap-2 bg-gradient-to-r from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] px-4 py-2 rounded-xl border border-[rgba(100,100,115,0.4)]">
            <svg className="w-4 h-4 text-cyan-400" fill="none" viewBox="0 0 16 16">
              <path d="M8 1L10 5L14 6L11 9L12 13L8 11L4 13L5 9L2 6L6 5L8 1Z" fill="currentColor" opacity="0.2" />
              <path d="M8 1L10 5L14 6L11 9L12 13L8 11L4 13L5 9L2 6L6 5L8 1Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span className="text-[#c1c5cc] text-sm font-medium">AI 驱动分析</span>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6">
          {/* 专家共识 */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="group relative bg-gradient-to-br from-[rgba(35,35,45,0.95)] to-[rgba(45,45,55,0.95)] rounded-2xl p-6 border border-[rgba(100,100,115,0.4)] backdrop-blur-sm hover:border-[rgba(57,255,20,0.3)] hover:shadow-[0_0_30px_rgba(57,255,20,0.08)] transition-all duration-500 overflow-hidden"
          >
            {/* 装饰性背景光效 */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[rgba(57,255,20,0.05)] rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
            
            <div className="relative z-10">
              <div className="flex items-start gap-4 mb-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-[rgba(57,255,20,0.2)] to-[rgba(57,255,20,0.05)] flex items-center justify-center border border-[rgba(57,255,20,0.3)] group-hover:scale-110 transition-transform duration-300">
                  <svg className="w-6 h-6 text-[#39ff14]" fill="none" viewBox="0 0 24 24">
                    <path d="M12 2L15 8.5L22 9.5L17 14.5L18 21.5L12 18.5L6 21.5L7 14.5L2 9.5L9 8.5L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <circle cx="12" cy="12" r="3" fill="currentColor" opacity="0.3" />
                  </svg>
                </div>
                <div className="flex-1">
                  <h3 className="text-[#e8e8ec] text-xl font-bold mb-2 flex items-center gap-2 group-hover:text-[#39ff14] transition-colors duration-300">
                    <span>专家共识</span>
                    <div className="h-px flex-1 bg-gradient-to-r from-[rgba(57,255,20,0.4)] to-transparent" />
                  </h3>
                  <p className="text-[#7a7a88] text-xs uppercase tracking-wider font-medium">Cross-Expert Consensus</p>
                </div>
              </div>
              
              <div className="relative pl-16">
                <div className="absolute left-6 top-0 bottom-0 w-px bg-gradient-to-b from-[rgba(57,255,20,0.4)] via-[rgba(57,255,20,0.2)] to-transparent" />
                <div className="text-[#c1c5cc] leading-relaxed text-[14px] space-y-2">
                  <p className="mb-2">所有专家一致认为：</p>
                  <p className="flex items-start gap-2">
                    <span className="text-[#39ff14] font-medium flex-shrink-0">1）</span>
                    <span>谎言从社会行为转变为具有直接物理后果的灾难性行为，导致世界淹没；</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span className="text-[#39ff14] font-medium flex-shrink-0">2）</span>
                    <span>社会将围绕"言语真实性"彻底重构，形成严格的言语监控与验证体系；</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span className="text-[#39ff14] font-medium flex-shrink-0">3）</span>
                    <span>权力结构发生根本转变，掌握真相验证技术的群体成为新精英；</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span className="text-[#39ff14] font-medium flex-shrink-0">4）</span>
                    <span>生存环境面临毁灭性威胁，文明需发展防洪、水上生存等适应性技术；</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span className="text-[#39ff14] font-medium flex-shrink-0">5）</span>
                    <span>历史、文化、经济等所有领域都将以最小化谎言为核心原则。</span>
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* 涌现洞察 */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            className="group relative bg-gradient-to-br from-[rgba(35,35,45,0.95)] to-[rgba(45,45,55,0.95)] rounded-2xl p-6 border border-[rgba(100,100,115,0.4)] backdrop-blur-sm hover:border-cyan-400/30 hover:shadow-[0_0_30px_rgba(34,211,238,0.08)] transition-all duration-500 overflow-hidden"
          >
            {/* 装饰性背景光效 */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-400/5 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
            
            <div className="relative z-10">
              <div className="flex items-start gap-4 mb-5">
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-400/20 to-cyan-400/5 flex items-center justify-center border border-cyan-400/30 group-hover:scale-110 transition-transform duration-300">
                  <svg className="w-6 h-6 text-cyan-400" fill="none" viewBox="0 0 24 24">
                    <path d="M12 3L13.5 8.5L19 10L14.5 14.5L16 20L12 17L8 20L9.5 14.5L5 10L10.5 8.5L12 3Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M12 8V12L14 14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <div className="flex-1">
                  <h3 className="text-[#e8e8ec] text-xl font-bold mb-2 flex items-center gap-2 group-hover:text-cyan-400 transition-colors duration-300">
                    <span>涌现洞察</span>
                    <div className="h-px flex-1 bg-gradient-to-r from-cyan-400/40 to-transparent" />
                  </h3>
                  <p className="text-[#7a7a88] text-xs uppercase tracking-wider font-medium">Emergent Insights</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  {
                    title: "言语真实性成为新物理定律",
                    content: "语言行为直接驱动地质与气候变化，形成'语言-现实因果律'，迫使文明发展出超现实主义思维和极端精确的交流系统。",
                    IconComponent: Atom,
                    iconColor: "#22d3ee"
                  },
                  {
                    title: "淹没循环文明模式",
                    content: "历史呈现'言语积累-淹没-重建'的循环，文明持续时间取决于社会维持真实性的能力，考古与历史研究本身成为高危活动。",
                    IconComponent: RefreshCw,
                    iconColor: "#06b6d4"
                  },
                  {
                    title: "真相极权主义悖论",
                    content: "为生存必须建立全面言语监控，但这可能导致病态诚实文化、情感表达崩溃、言论自由消失，形成以'防止淹没'为名的新型压迫。",
                    IconComponent: Scale,
                    iconColor: "#0891b2"
                  },
                  {
                    title: "经济价值体系颠覆",
                    content: "真实信息成为最稀缺资源，防淹技术、真实性验证工具主导市场，但过度风险规避可能抑制创新，真实性垄断加剧不平等。",
                    IconComponent: Gem,
                    iconColor: "#0e7490"
                  },
                ].map((insight, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.9 + i * 0.1 }}
                    className="group/card relative bg-[rgba(25,25,35,0.6)] rounded-xl p-5 border border-[rgba(80,80,95,0.3)] hover:border-cyan-400/40 hover:bg-[rgba(34,211,238,0.03)] transition-all duration-300"
                  >
                    <div className="flex items-start gap-3">
                      <insight.IconComponent 
                        className="w-5 h-5 flex-shrink-0 mt-0.5 group-hover/card:scale-110 transition-transform duration-300" 
                        style={{ color: insight.iconColor }}
                        strokeWidth={1.5}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-cyan-300 text-sm font-bold mb-2 leading-snug">
                          {insight.title}
                        </p>
                        <p className="text-[#c1c5cc] text-xs leading-relaxed">
                          {insight.content}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* 风险评估 */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.9 }}
            className="group relative bg-gradient-to-br from-[rgba(180,80,60,0.15)] to-[rgba(150,60,40,0.08)] rounded-2xl p-6 border border-[rgba(180,80,60,0.4)] backdrop-blur-sm hover:border-[rgba(180,80,60,0.6)] hover:shadow-[0_0_30px_rgba(180,80,60,0.1)] transition-all duration-500 overflow-hidden"
          >
            {/* 装饰性背景光效 */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-red-400/5 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
            
            <div className="relative z-10">
              <div className="flex items-start gap-4 mb-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-red-400/20 to-red-400/5 flex items-center justify-center border border-red-400/30 group-hover:scale-110 transition-transform duration-300">
                  <svg className="w-6 h-6 text-red-400" fill="none" viewBox="0 0 24 24">
                    <path d="M12 2L2 22H22L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M12 9V13" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
                    <circle cx="12" cy="17" r="0.5" fill="currentColor" stroke="currentColor" strokeWidth="1.5" />
                  </svg>
                </div>
                <div className="flex-1">
                  <h3 className="text-red-300 text-xl font-bold mb-2 flex items-center gap-2 group-hover:text-red-400 transition-colors duration-300">
                    <span>风险评估</span>
                    <div className="h-px flex-1 bg-gradient-to-r from-red-400/40 to-transparent" />
                    <span className="text-red-400 text-sm font-black px-3 py-1 bg-red-400/10 rounded-lg border border-red-400/30">极高</span>
                  </h3>
                  <p className="text-[#7a7a88] text-xs uppercase tracking-wider font-medium">Risk Assessment</p>
                </div>
              </div>
              
              <div className="relative pl-16">
                <div className="absolute left-6 top-0 bottom-0 w-px bg-gradient-to-b from-red-400/40 via-red-400/20 to-transparent" />
                <div className="space-y-3">
                  <p className="text-[#c1c5cc] text-sm leading-loose">
                    <span className="inline-flex items-center gap-2 text-red-400 font-bold mb-2">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 16 16">
                        <circle cx="8" cy="8" r="7" opacity="0.2" />
                        <path d="M8 4V9M8 11V11.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" fill="none" />
                      </svg>
                      极高风险级别
                    </span>
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      { label: "生存风险", text: "若无约束机制，世界可能迅速完全淹没，文明崩溃" },
                      { label: "社会风险", text: "极权化真相政权滥用监控，剥夺基本自由，导致人性异化" },
                      { label: "经济风险", text: "过度风险规避使系统停滞，真实性垄断形成新特权阶层" },
                      { label: "认知风险", text: "语言焦虑普遍化，隐喻与模糊表达消亡，思维极端精确化但可能催生规避编码系统" },
                    ].map((risk, i) => (
                      <div key={i} className="bg-[rgba(180,80,60,0.1)] rounded-lg p-3 border border-[rgba(180,80,60,0.25)] hover:border-[rgba(180,80,60,0.4)] transition-colors duration-300">
                        <p className="text-red-300 text-xs font-bold mb-1.5 flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                          {risk.label}
                        </p>
                        <p className="text-[#c1c5cc] text-xs leading-relaxed">{risk.text}</p>
                      </div>
                    ))}
                  </div>
                  <p className="text-[#c1c5cc] text-xs leading-relaxed pt-2 border-t border-red-400/20">
                    <span className="text-red-300 font-medium">附加威胁：</span>国际协作脆弱可能引发全球性谎言连锁灾难。
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}

function Navigation() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-20 px-4 sm:px-8 lg:px-12 xl:px-16 py-4 sm:py-6 backdrop-blur-md bg-[rgba(15,15,20,0.8)]">
      <div className="flex items-center justify-between w-full max-w-[1920px] mx-auto">
        {/* 左侧：返回按钮 + Logo 区域 */}
        <div className="flex items-center gap-3">
          {/* 返回按钮 */}
          <button 
            onClick={() => window.history.back()}
            className="group size-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(85,85,100,0.85)] border border-[rgba(110,110,125,0.4)] hover:border-[rgba(57,255,20,0.4)] transition-all duration-300 flex items-center justify-center"
            aria-label="返回上一页"
          >
            <ArrowLeft className="w-5 h-5 text-[#c1c5cc] group-hover:text-[#39ff14] transition-colors duration-300" strokeWidth={2} />
          </button>

          {/* WORLD 标签 */}
          <div className="bg-gradient-to-b from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] rounded-[18px] px-4 py-2 border border-[rgba(100,100,115,0.4)]">
            <p
              className="font-black text-[16px] tracking-[0.8px] not-italic"
              style={{
                color: "#39ff14",
                textShadow:
                  "0 0 10px rgba(57, 255, 20, 0.8), 0 0 20px rgba(57, 255, 20, 0.5), 0 0 30px rgba(57, 255, 20, 0.3), 0 2px 4px rgba(0, 0, 0, 0.8)",
                WebkitTextStroke:
                  "0.5px rgba(57, 255, 20, 0.3)",
              }}
            >
              WORLD
            </p>
          </div>

          {/* BETA 标签 */}
          <div className="bg-[rgba(60,60,70,0.6)] rounded-[18px] px-3 py-1 border border-[rgba(100,100,110,0.3)]">
            <p className="text-[#c1c5cc] text-[11px] tracking-[0.55px]">
              BETA
            </p>
          </div>
        </div>

        {/* 右侧：操作按钮组 */}
        <div className="flex items-center gap-3">
          {/* 简体中文按钮 */}
          <button className="hidden sm:block rounded-[14px] px-4 py-2 bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors">
            <span className="text-[#e8e8ec] text-[14px]">
              简体中文
            </span>
          </button>

          {/* 图标按钮1 */}
          <button className="size-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors flex items-center justify-center">
            <svg
              className="w-5 h-5"
              fill="none"
              viewBox="0 0 20 20"
            >
              <g clipPath="url(#clip0_1_55)">
                <path
                  d={svgPaths.p2b260000}
                  stroke="#C1C5CC"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.66667"
                />
              </g>
              <defs>
                <clipPath id="clip0_1_55">
                  <rect fill="white" height="20" width="20" />
                </clipPath>
              </defs>
            </svg>
          </button>

          {/* 图标按钮2 */}
          <button className="size-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors flex items-center justify-center">
            <svg
              className="w-5 h-5"
              fill="none"
              viewBox="0 0 20 20"
            >
              <path
                d={svgPaths.p1d939600}
                stroke="#C1C5CC"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.66667"
              />
              <path
                d={svgPaths.p5272800}
                stroke="#C1C5CC"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.66667"
              />
            </svg>
          </button>

          {/* 计数器按钮 */}
          <div className="hidden sm:flex items-center gap-2 bg-[rgba(60,60,70,0.6)] rounded-[12px] px-3 py-2 border border-[rgba(100,100,110,0.3)]">
            <svg
              className="w-4 h-4"
              fill="none"
              viewBox="0 0 16 16"
            >
              <g clipPath="url(#clip0_1_58)">
                <path
                  d={svgPaths.p3a6156f0}
                  stroke="#C1C5CC"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.33333"
                />
                <path
                  d={svgPaths.p11fb83c0}
                  stroke="#C1C5CC"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.33333"
                />
                <path
                  d="M4.66667 4H5.33333V6.66667"
                  stroke="#C1C5CC"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.33333"
                />
                <path
                  d={svgPaths.p583e380}
                  stroke="#C1C5CC"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.33333"
                />
              </g>
              <defs>
                <clipPath id="clip0_1_58">
                  <rect fill="white" height="16" width="16" />
                </clipPath>
              </defs>
            </svg>
            <span className="text-[#e8e8ec] text-[13px]">
              1,145
            </span>
          </div>

          {/* 图标按钮3 */}
          <button className="size-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors flex items-center justify-center">
            <svg
              className="w-5 h-5"
              fill="none"
              viewBox="0 0 20 20"
            >
              <path
                d={svgPaths.p1beb9580}
                stroke="#C1C5CC"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.66667"
              />
              <path
                d={svgPaths.p32ab0300}
                stroke="#C1C5CC"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.66667"
              />
            </svg>
          </button>

          {/* 图标按钮4 */}
          <button className="size-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors flex items-center justify-center">
            <svg
              className="w-5 h-5"
              fill="none"
              viewBox="0 0 20 20"
            >
              <path
                d={svgPaths.p654be80}
                stroke="#C1C5CC"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.66667"
              />
            </svg>
          </button>
        </div>
      </div>
    </nav>
  );
}

export default function App() {
  return (
    <PremiumBackground>
      <div className="size-full overflow-y-auto">
        <Navigation />
        <MainContent />
      </div>
    </PremiumBackground>
  );
}