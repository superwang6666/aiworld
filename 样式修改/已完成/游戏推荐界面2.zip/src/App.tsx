import PremiumBackground from "./components/PremiumBackground";
import { motion } from "motion/react";
import {
  MessageCircle,
  Github,
  Coins,
  User,
  Star,
} from "lucide-react";

export default function App() {
  return (
    <PremiumBackground>
      <div className="size-full flex flex-col">
        {/* 导航栏 */}
        <nav className="px-4 sm:px-8 lg:px-12 xl:px-16 py-4 sm:py-6 flex items-center justify-between">
          {/* Logo区域 */}
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="flex items-center gap-2 sm:gap-2.5 bg-gradient-to-r from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] rounded-[18px] px-4 py-2 border border-[rgba(100,100,115,0.4)] backdrop-blur-sm">
              <span
                className="font-black tracking-wider"
                style={{
                  color: "#39ff14",
                  textShadow:
                    "0 0 10px rgba(57, 255, 20, 0.8), 0 0 20px rgba(57, 255, 20, 0.5), 0 0 30px rgba(57, 255, 20, 0.3), 0 2px 4px rgba(0, 0, 0, 0.8)",
                  WebkitTextStroke:
                    "0.5px rgba(57, 255, 20, 0.3)",
                }}
              >
                WORLD
              </span>
            </div>
            <div className="bg-[rgba(60,60,70,0.6)] rounded-[18px] px-3 py-1 border border-[rgba(100,100,110,0.3)]">
              <span className="text-[11px] text-[#c1c5cc] tracking-wider">
                BETA
              </span>
            </div>
          </div>

          {/* 右侧按钮组 */}
          <div className="flex items-center gap-2 sm:gap-3">
            <button className="hidden sm:flex rounded-[14px] px-4 py-2 bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors text-[#e8e8ec] text-[14px]">
              简体中文
            </button>

            <button className="size-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-[#c1c5cc]" />
            </button>

            <button className="size-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors flex items-center justify-center">
              <Github className="w-5 h-5 text-[#c1c5cc]" />
            </button>

            <div className="flex items-center gap-2 bg-[rgba(60,60,70,0.6)] rounded-[12px] px-3 py-1.5 border border-[rgba(100,100,110,0.3)]">
              <Coins className="w-4 h-4 text-[#c1c5cc]" />
              <span className="text-[13px] text-[#e8e8ec] font-medium">
                1,145
              </span>
            </div>

            <button className="size-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors flex items-center justify-center">
              <User className="w-5 h-5 text-[#c1c5cc]" />
            </button>

            <button className="size-[36px] rounded-[12px] bg-[rgba(60,60,70,0.6)] hover:bg-[rgba(70,70,80,0.8)] border border-[rgba(100,100,110,0.3)] transition-colors flex items-center justify-center">
              <Star className="w-5 h-5 text-[#c1c5cc]" />
            </button>
          </div>
        </nav>

        {/* 主内容区 */}
        <main className="flex-1 px-4 sm:px-8 lg:px-16 py-8 sm:py-12 overflow-auto">
          <div className="max-w-5xl mx-auto">
            {/* 标题区 */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="mb-4 sm:mb-6"
            ></motion.div>

            {/* 分析卡片 */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-gradient-to-r from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] rounded-2xl p-6 sm:p-8 border border-[rgba(100,100,115,0.4)] backdrop-blur-sm mb-6"
            >
              {/* 核心理念标题 */}
              <h2 className="text-lg sm:text-xl text-[#e8e8ec] mb-6 font-medium">
                命运源核心理念
              </h2>

              {/* 游戏推荐列表 */}
              <div className="space-y-6">
                {/* The Stanley Parable */}
                <GameCard
                  title="The Stanley Parable"
                  tags={[
                    "探索",
                    "叙事实验",
                    "玩家选择",
                    "存在感反思",
                    "悖论困境",
                  ]}
                  core="每个选择都是一个陷阱，或者关键碰撞"
                  reason="这款游戏挑战了玩家与叙事的关系，通过讽刺与反思提出深刻问题，多重结局与循环玩法"
                />

                {/* Portal 2 */}
                <GameCard
                  title="Portal 2"
                  tags={[
                    "解谜",
                    "空间探索",
                    "时间扭曲",
                    "荒诞幽默",
                    "科技挑战",
                  ]}
                  core="每个门都可能通向另一侧，而非线性的答案"
                  reason="这款游戏结合了精巧的空间解谜与幽默叙事，让玩家在科技与荒诞中探索新的维度与可能性"
                />

                {/* Gravity Rush */}
                <GameCard
                  title="Gravity Rush"
                  tags={[
                    "自由落体",
                    "重力操控",
                    "空间扭曲",
                    "多维探索",
                  ]}
                  core="没有天空或地面，只有重力的界限"
                  reason="与前两款游戏类似，挑战空间认知，通过重力机制创造独特探索体验，让玩家打破日常空间限制"
                />
              </div>
            </motion.div>

            {/* 核心维度总结 */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-gradient-to-r from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] rounded-2xl p-6 sm:p-8 border border-[rgba(100,100,115,0.4)] backdrop-blur-sm mb-6"
            >
              <h3 className="text-lg text-[#e8e8ec] mb-4 font-medium">
                核心维度总结
              </h3>
              <ul className="space-y-2.5 text-[#c1c5cc] text-[14px] sm:text-[15px]">
                <li className="flex items-start">
                  <span className="text-[#39ff14] mr-2 mt-0.5">
                    •
                  </span>
                  <span>对选择与路径的探索</span>
                </li>
                <li className="flex items-start">
                  <span className="text-[#39ff14] mr-2 mt-0.5">
                    •
                  </span>
                  <span>超现实的叙事系统</span>
                </li>
                <li className="flex items-start">
                  <span className="text-[#39ff14] mr-2 mt-0.5">
                    •
                  </span>
                  <span>玩家与环境的哲思互动</span>
                </li>
              </ul>
            </motion.div>

            {/* 世界观推荐意图 */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="bg-gradient-to-r from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] rounded-2xl p-6 sm:p-8 border border-[rgba(100,100,115,0.4)] backdrop-blur-sm"
            >
              <h3 className="text-lg text-[#e8e8ec] mb-4 font-medium">
                世界观推荐意图
              </h3>
              <div className="space-y-3 text-[#c1c5cc] text-[14px] sm:text-[15px] leading-relaxed">
                <p>
                  <span className="text-[#e8e8ec] font-medium">
                    1.
                  </span>{" "}
                  从总体来说，你喜欢一个充满哲理与自由性的游戏环境，如《The
                  Stanley
                  Parable》的反讽叙事，让玩家对世界与自身定位提出质疑。
                </p>
                <p>
                  <span className="text-[#e8e8ec] font-medium">
                    2.
                  </span>{" "}
                  空间层面，你注重解谜与空间的创新玩法与空间感。如《Portal
                  2》的传送门，《Gravity
                  Rush》的重力机制，都让玩家体验到玩法上的深度与多样性。
                </p>
                <p>
                  <span className="text-[#e8e8ec] font-medium">
                    3.
                  </span>{" "}
                  叙事层面，从人物角色背后的命题，到《Portal
                  2》的幽默对话，比较关注有深度的空间玩法与叙事提升。
                </p>
                <p>
                  <span className="text-[#e8e8ec] font-medium">
                    4.
                  </span>{" "}
                  形而上学的玩法，创造了《Gravity
                  Rush》的重建感，让玩家把传统认知中的世界重新塑造，形成更自由的空间玩法。
                </p>
              </div>
            </motion.div>

            {/* 底部按钮 */}
            <div className="flex justify-center pb-12 mt-8 sm:mt-10">
              <motion.button
                className="group relative overflow-hidden px-10 sm:px-14 py-4 sm:py-5 bg-gradient-to-br from-[rgba(100,100,120,0.5)] via-[rgba(90,90,110,0.6)] to-[rgba(80,80,100,0.5)] backdrop-blur-md text-[#ebebf0] rounded-2xl border border-[rgba(130,130,150,0.3)] transition-all duration-500 flex items-center gap-4"
                style={{
                  boxShadow:
                    "0 8px 32px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255, 255, 255, 0.05) inset, 0 0 60px rgba(120, 100, 180, 0.1)",
                }}
                whileHover={{
                  scale: 1.03,
                  boxShadow:
                    "0 12px 48px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.1) inset, 0 0 80px rgba(120, 100, 180, 0.2)",
                }}
                whileTap={{ scale: 0.98 }}
              >
                {/* 背景扫光效果 */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent"
                  initial={{ x: "-100%" }}
                  whileHover={{ x: "100%" }}
                  transition={{
                    duration: 0.6,
                    ease: "easeInOut",
                  }}
                />

                {/* 发光边框效果 */}
                <div
                  className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{
                    background:
                      "linear-gradient(135deg, rgba(150, 130, 200, 0.3), rgba(100, 150, 200, 0.3), rgba(150, 130, 200, 0.3))",
                    filter: "blur(20px)",
                  }}
                />

                {/* 内容 */}
                <div className="relative flex items-center gap-4">
                  <motion.div
                    animate={{ rotate: [0, 360] }}
                    transition={{
                      duration: 20,
                      repeat: Infinity,
                      ease: "linear",
                    }}
                  >
                    <Star
                      className="w-5 h-5 sm:w-6 sm:h-6"
                      fill="rgba(235, 235, 240, 0.2)"
                    />
                  </motion.div>

                  <span className="text-base sm:text-lg font-medium tracking-wide">
                    应用此世界观
                  </span>

                  <motion.div
                    className="w-2.5 h-2.5 rounded-full relative"
                    style={{ backgroundColor: "#39ff14" }}
                    animate={{
                      opacity: [0.4, 1, 0.4],
                      scale: [1, 1.2, 1],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                    }}
                  >
                    <motion.div
                      className="absolute inset-0 rounded-full"
                      style={{ backgroundColor: "#39ff14" }}
                      animate={{
                        scale: [1, 2, 1],
                        opacity: [0.6, 0, 0.6],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                      }}
                    />
                  </motion.div>
                </div>
              </motion.button>
            </div>
          </div>
        </main>
      </div>
    </PremiumBackground>
  );
}

// 游戏卡片组件
function GameCard({
  title,
  tags,
  core,
  reason,
}: {
  title: string;
  tags: string[];
  core: string;
  reason: string;
}) {
  return (
    <div className="border-l-2 border-[rgba(100,100,115,0.4)] pl-4 sm:pl-6">
      <h3
        className="text-base sm:text-lg text-[#39ff14] mb-2 font-medium"
        style={{
          textShadow:
            "0 0 10px rgba(57, 255, 20, 0.6), 0 0 20px rgba(57, 255, 20, 0.3)",
        }}
      >
        {title}
      </h3>

      {/* 标签 */}
      <div className="flex flex-wrap gap-2 mb-3">
        {tags.map((tag, index) => (
          <span
            key={index}
            className="text-[11px] sm:text-[12px] px-2.5 py-1 bg-[rgba(60,60,70,0.6)] text-[#c1c5cc] rounded-lg border border-[rgba(100,100,110,0.3)]"
          >
            {tag}
          </span>
        ))}
      </div>

      {/* 核心元素 */}
      <div className="mb-2">
        <span className="text-[13px] text-[#7a7a88]">
          核心元素：
        </span>
        <span className="text-[13px] sm:text-[14px] text-[#e8e8ec] ml-1">
          {core}
        </span>
      </div>

      {/* 推荐原因 */}
      <div>
        <span className="text-[13px] text-[#7a7a88]">
          推荐原因：
        </span>
        <span className="text-[13px] sm:text-[14px] text-[#c1c5cc] ml-1">
          {reason}
        </span>
      </div>
    </div>
  );
}