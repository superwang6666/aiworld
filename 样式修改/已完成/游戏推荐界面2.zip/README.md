
  # 游戏推荐界面2

  This is a code bundle for 游戏推荐界面2. The original project is available at https://www.figma.com/design/2IvvHDXF3ev60uCNHGbjGz/%E6%B8%B8%E6%88%8F%E6%8E%A8%E8%8D%90%E7%95%8C%E9%9D%A22.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  