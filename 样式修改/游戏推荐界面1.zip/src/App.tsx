import { useState } from 'react';
import { motion } from 'motion/react';
import { Star, X, MessageSquare, Bell, Play, Check } from 'lucide-react';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import PremiumBackground from './components/PremiumBackground';

// 游戏数据
const games = [
  {
    id: 1,
    title: 'The Stanley Parable',
    genre: 'Indie, Adventure',
    date: '2013-10-17',
    description: '这是一款探索选择和自由的实验性叙事游戏。玩家扮演员工斯坦利,在办公室里独自一人。游戏通过旁白和玩家的选择来展开叙事。',
    metacritic: 88,
    rating: '4.4/5',
    image: 'https://images.unsplash.com/photo-1678580412374-002d553a1760?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0YWwlMjAyJTIwZ2FtZXxlbnwxfHx8fDE3Njk1ODYzMzJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    borderColor: 'rgba(255, 180, 100, 0.6)'
  },
  {
    id: 2,
    title: 'Portal 2',
    genre: 'Shooter, Puzzle',
    date: '2011-04-19',
    description: '延续经典的传送门解谜玩法,加入更丰富的关卡设计。基于传送门枪的独特机制,创建传送门解决各类空间谜题。',
    metacritic: 95,
    rating: '4.6/5',
    image: 'https://images.unsplash.com/photo-1684773585761-fde68b4ece42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwdXp6bGUlMjBpbmRpZSUyMGdhbWUlMjBjb2xvcmZ1bHxlbnwxfHx8fDE3Njk1ODYzMzN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    borderColor: 'rgba(100, 150, 255, 0.6)'
  },
  {
    id: 3,
    title: 'Baba Is You',
    genre: 'Indie, Puzzle',
    date: '2019-03-13',
    description: '颠覆传统的解谜游戏,玩家可以改变游戏规则本身。通过推动文字方块来改变游戏机制,是每个关卡都需要创造性思考的独特体验。',
    metacritic: 86,
    rating: '4.4/5',
    image: 'https://images.unsplash.com/photo-1611546191222-96fb7afd5af9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMHB1enpsZSUyMGdhbWV8ZW58MXx8fHwxNzY5NTg2MzMzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    borderColor: 'rgba(200, 100, 255, 0.6)'
  },
  {
    id: 4,
    title: 'The Witness',
    genre: 'Indie, Adventure, Puzzle',
    date: '2016-01-25',
    description: '探索神秘孤岛的开放世界解谜游戏。岛上布满各类谜题,玩家需要观察和学习不同的解谜规则,每个区域都有独特的挑战。',
    metacritic: 87,
    rating: '4.0/5',
    image: 'https://images.unsplash.com/photo-1655500025272-5e9246e62716?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxteXN0ZXJpb3VzJTIwaXNsYW5kJTIwZ2FtZXxlbnwxfHx8fDE3Njk1ODYzMzN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    borderColor: 'rgba(100, 220, 180, 0.6)'
  },
  {
    id: 5,
    title: 'Antichamber',
    genre: 'Indie, Puzzle',
    date: '2013-01-31',
    description: '非常规的第一人称解谜游戏,打破传统空间逻辑。玩家在不断变化的迷宫中探索,挑战对空间和维度的认知。',
    metacritic: 82,
    rating: '4.1/5',
    image: 'https://images.unsplash.com/photo-1764085793275-9cd0fad57a74?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMG1hemUlMjBwZXJzcGVjdGl2ZXxlbnwxfHx8fDE3Njk1ODYzMzR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    borderColor: 'rgba(150, 100, 255, 0.6)'
  },
  {
    id: 6,
    title: 'Superliminal',
    genre: 'Indie, Puzzle',
    date: '2019-11-12',
    description: '基于视觉错觉的解谜游戏。利用强制透视的独特机制来解决谜题,物体的大小取决于观察距离,这创造了意想不到的解法。',
    metacritic: 77,
    rating: '4.2/5',
    image: 'https://images.unsplash.com/photo-1752154344437-44bd7480e8ee?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXJyZWFsJTIwcHV6emxlJTIwb3B0aWNhbCUyMGlsbHVzaW9ufGVufDF8fHx8MTc2OTU4NjMzNHww&ixlib=rb-4.1.0&q=80&w=1080',
    borderColor: 'rgba(255, 100, 150, 0.6)'
  },
  {
    id: 7,
    title: 'The Talos Principle',
    genre: 'Indie, Adventure, Puzzle',
    date: '2014-12-11',
    description: '哲学主题的第一人称解谜游戏。玩家作为人工智能,通过解决各类谜题来探索关于意识和存在的深刻问题。',
    metacritic: 85,
    rating: '4.2/5',
    image: 'https://images.unsplash.com/photo-1759997724812-16bfaa271b49?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmNpZW50JTIwcnVpbnMlMjBwaGlsb3NvcGhpY2FsfGVufDF8fHx8MTc2OTU4NjMzNHww&ixlib=rb-4.1.0&q=80&w=1080',
    borderColor: 'rgba(255, 200, 100, 0.6)'
  },
  {
    id: 8,
    title: 'Gravity Rush',
    genre: 'Adventure, Action',
    date: '2012-02-08',
    description: '独特的重力操控动作游戏。玩家可以操纵重力方向,在城市中自由飞行,战斗和探索都围绕这个核心机制展开。',
    metacritic: 83,
    rating: '4.0/5',
    image: 'https://images.unsplash.com/photo-1678580412374-002d553a1760?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0YWwlMjAyJTIwZ2FtZXxlbnwxfHx8fDE3Njk1ODYzMzJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    borderColor: 'rgba(100, 180, 255, 0.6)'
  }
];

function App() {
  const [showBanner, setShowBanner] = useState(true);
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);
  const [selectedGames, setSelectedGames] = useState<number[]>([]);

  const toggleGameSelection = (gameId: number) => {
    setSelectedGames(prev => 
      prev.includes(gameId) 
        ? prev.filter(id => id !== gameId)
        : [...prev, gameId]
    );
  };

  return (
    <PremiumBackground>
      <div className="min-h-screen flex flex-col">
        {/* 顶部导航栏 */}
        <header className="px-4 sm:px-8 lg:px-12 xl:px-16 py-4 sm:py-6 flex items-center justify-between">
          <div className="flex items-center gap-3 sm:gap-4">
            <button className="rounded-[14px] px-4 py-2 bg-[rgba(70,70,85,0.7)] hover:bg-[rgba(85,85,100,0.85)] text-[#ebebf0] text-[14px] backdrop-blur-sm border border-[rgba(110,110,125,0.4)] hover:border-[rgba(130,130,145,0.6)] transition-all duration-300">
              WORLD
            </button>
            <span className="rounded-[18px] px-3 py-1 bg-[rgba(25,25,35,0.6)] text-[#7a7a88] text-xs border border-[rgba(80,80,95,0.3)] backdrop-blur-sm">
              BETA
            </span>
          </div>
          <div className="flex items-center gap-3 sm:gap-4">
            <button className="hidden sm:block text-[#c1c5cc] hover:text-[#e8e8ec] text-[14px] transition-colors">
              简体中文
            </button>
            <button className="size-[36px] rounded-[12px] flex items-center justify-center bg-[rgba(70,70,85,0.7)] hover:bg-[rgba(85,85,100,0.85)] border border-[rgba(100,100,110,0.3)] hover:border-[rgba(130,130,145,0.6)] text-[#c1c5cc] hover:text-[#e8e8ec] transition-all duration-300">
              <MessageSquare className="w-5 h-5" />
            </button>
            <button className="size-[36px] rounded-[12px] flex items-center justify-center bg-[rgba(70,70,85,0.7)] hover:bg-[rgba(85,85,100,0.85)] border border-[rgba(100,100,110,0.3)] hover:border-[rgba(130,130,145,0.6)] text-[#c1c5cc] hover:text-[#e8e8ec] transition-all duration-300">
              <Bell className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* 提示横幅 */}
        {showBanner && (
          <div className="max-w-[1400px] mx-auto w-full px-4 sm:px-8 lg:px-16 mb-8">
            <div className="max-w-[640px] mx-auto bg-gradient-to-r from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] backdrop-blur-sm border border-[rgba(100,100,115,0.4)] rounded-2xl px-4 sm:px-6 py-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <motion.div 
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: '#39ff14' }}
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
                <span className="text-[#c1c5cc] text-[13px] sm:text-[14px]">
                  本页仅为功能展示！点击"导出这些",制造跨时间有一致性
                </span>
              </div>
              <button 
                onClick={() => setShowBanner(false)}
                className="text-[#7a7a88] hover:text-[#c1c5cc] transition-colors flex-shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* 游戏卡片网格 */}
        <div className="max-w-[1400px] mx-auto w-full px-4 sm:px-8 lg:px-12 xl:px-16 mb-16 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
            {games.map((game) => (
              <motion.div
                key={game.id}
                className="group relative bg-gradient-to-r from-[rgba(35,35,45,0.9)] to-[rgba(45,45,55,0.9)] backdrop-blur-sm border border-[rgba(100,100,115,0.4)] hover:border-[rgba(130,130,145,0.6)] rounded-2xl overflow-hidden transition-all duration-300"
                onMouseEnter={() => setHoveredCard(game.id)}
                onMouseLeave={() => setHoveredCard(null)}
                whileHover={{ scale: 1.02 }}
                transition={{ duration: 0.3 }}
              >
                {/* 复选框 - 卡片右上角 */}
                <motion.button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleGameSelection(game.id);
                  }}
                  className="absolute top-4 right-4 sm:top-5 sm:right-5 w-8 h-8 sm:w-9 sm:h-9 rounded-full backdrop-blur-xl border transition-all duration-500 flex items-center justify-center z-20 group/checkbox"
                  style={{
                    background: selectedGames.includes(game.id) 
                      ? 'radial-gradient(circle, rgba(57, 255, 20, 0.25) 0%, rgba(57, 255, 20, 0.1) 50%, rgba(40, 40, 50, 0.95) 100%)' 
                      : 'radial-gradient(circle, rgba(80, 80, 95, 0.4) 0%, rgba(60, 60, 75, 0.6) 50%, rgba(40, 40, 50, 0.9) 100%)',
                    borderColor: selectedGames.includes(game.id)
                      ? 'rgba(57, 255, 20, 0.5)'
                      : 'rgba(110, 110, 125, 0.3)',
                    boxShadow: selectedGames.includes(game.id)
                      ? '0 0 30px rgba(57, 255, 20, 0.4), 0 0 60px rgba(57, 255, 20, 0.2), 0 4px 20px rgba(0, 0, 0, 0.4), inset 0 1px 2px rgba(255, 255, 255, 0.1)'
                      : '0 4px 16px rgba(0, 0, 0, 0.3), inset 0 1px 2px rgba(255, 255, 255, 0.05)'
                  }}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {/* 外圈光环 */}
                  {selectedGames.includes(game.id) && (
                    <motion.div
                      className="absolute inset-0 rounded-full"
                      style={{
                        background: 'radial-gradient(circle, rgba(57, 255, 20, 0.3) 0%, transparent 70%)',
                        filter: 'blur(8px)'
                      }}
                      animate={{
                        scale: [1, 1.4, 1],
                        opacity: [0.6, 0.3, 0.6]
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                    />
                  )}
                  
                  {/* 中心图标 */}
                  <motion.div
                    className="relative"
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ 
                      scale: selectedGames.includes(game.id) ? 1 : 0,
                      rotate: selectedGames.includes(game.id) ? 0 : -180,
                      opacity: selectedGames.includes(game.id) ? 1 : 0
                    }}
                    transition={{ 
                      type: "spring",
                      stiffness: 200,
                      damping: 15
                    }}
                  >
                    <Check 
                      className="w-4 h-4 sm:w-5 sm:h-5" 
                      strokeWidth={3}
                      style={{
                        color: '#39ff14',
                        filter: 'drop-shadow(0 0 4px rgba(57, 255, 20, 0.8))'
                      }}
                    />
                  </motion.div>
                  
                  {/* 未选中时的内圈 */}
                  {!selectedGames.includes(game.id) && (
                    <motion.div
                      className="absolute w-4 h-4 sm:w-5 sm:h-5 rounded-full border-2"
                      style={{
                        borderColor: 'rgba(150, 150, 165, 0.5)'
                      }}
                      whileHover={{
                        borderColor: 'rgba(180, 180, 195, 0.7)',
                        scale: 1.1
                      }}
                      transition={{ duration: 0.2 }}
                    />
                  )}
                </motion.button>

                <div 
                  className="flex gap-4 sm:gap-5 p-4 sm:p-5 cursor-pointer"
                  onClick={() => toggleGameSelection(game.id)}
                >
                  {/* 游戏图片 */}
                  <div className="relative flex-shrink-0">
                    <div 
                      className="relative w-[120px] sm:w-[160px] h-[150px] sm:h-[200px] rounded-xl overflow-hidden p-[2px]"
                      style={{
                        background: `linear-gradient(135deg, ${game.borderColor}, transparent)`
                      }}
                    >
                      <div className="w-full h-full rounded-xl overflow-hidden bg-[#0f0f14]">
                        <ImageWithFallback
                          src={game.image}
                          alt={game.title}
                          className="w-full h-full object-cover transition-all duration-300 group-hover:scale-110 saturate-[1.2] contrast-[1.1] brightness-[0.9]"
                          style={{
                            imageRendering: 'auto'
                          }}
                        />
                      </div>
                    </div>
                    
                    {/* 悬停播放按钮 */}
                    <motion.div 
                      className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm rounded-xl"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: hoveredCard === game.id ? 1 : 0 }}
                      transition={{ duration: 0.3 }}
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center rounded-full bg-[rgba(235,235,240,0.9)] text-[#0f0f14]">
                        <Play className="w-5 h-5 sm:w-6 sm:h-6 ml-1" fill="currentColor" />
                      </div>
                    </motion.div>
                  </div>

                  {/* 游戏信息 */}
                  <div className="flex-1 flex flex-col justify-between py-1">
                    <div>
                      <h3 className="text-[#ebebf0] text-lg sm:text-xl mb-2 group-hover:text-[#e8e8ec] transition-colors">
                        {game.title}
                      </h3>
                      <p className="text-[#7a7a88] text-xs sm:text-sm mb-3">
                        {game.genre} · {game.date}
                      </p>
                      <p className="text-[#c1c5cc] text-xs sm:text-sm leading-relaxed line-clamp-3">
                        {game.description}
                      </p>
                    </div>
                    
                    {/* 评分标签 */}
                    <div className="flex items-center gap-2 sm:gap-3 mt-4">
                      <div className="px-3 py-1.5 bg-[rgba(25,25,35,0.6)] backdrop-blur-sm rounded-lg border border-[rgba(80,80,95,0.3)]">
                        <span className="text-[#c1c5cc] text-xs font-medium">
                          MC: {game.metacritic}
                        </span>
                      </div>
                      <div className="px-3 py-1.5 bg-[rgba(25,25,35,0.6)] backdrop-blur-sm rounded-lg border border-[rgba(80,80,95,0.3)]">
                        <span className="text-[#c1c5cc] text-xs font-medium">
                          {game.rating}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 卡片发光效果 */}
                <motion.div 
                  className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-300 pointer-events-none rounded-2xl"
                  style={{
                    background: `radial-gradient(circle at 50% 50%, ${game.borderColor}, transparent 70%)`
                  }}
                />
              </motion.div>
            ))}
          </div>
        </div>

        {/* 底部按钮 */}
        <div className="flex justify-center pb-20">
          <motion.button 
            className="group relative overflow-hidden px-10 sm:px-14 py-4 sm:py-5 bg-gradient-to-br from-[rgba(100,100,120,0.5)] via-[rgba(90,90,110,0.6)] to-[rgba(80,80,100,0.5)] backdrop-blur-md text-[#ebebf0] rounded-2xl border border-[rgba(130,130,150,0.3)] transition-all duration-500 flex items-center gap-4"
            style={{
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255, 255, 255, 0.05) inset, 0 0 60px rgba(120, 100, 180, 0.1)'
            }}
            whileHover={{ 
              scale: 1.03,
              boxShadow: '0 12px 48px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.1) inset, 0 0 80px rgba(120, 100, 180, 0.2)'
            }}
            whileTap={{ scale: 0.98 }}
          >
            {/* 背景扫光效果 */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent"
              initial={{ x: '-100%' }}
              whileHover={{ x: '100%' }}
              transition={{ duration: 0.6, ease: "easeInOut" }}
            />
            
            {/* 发光边框效果 */}
            <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
              style={{
                background: 'linear-gradient(135deg, rgba(150, 130, 200, 0.3), rgba(100, 150, 200, 0.3), rgba(150, 130, 200, 0.3))',
                filter: 'blur(20px)'
              }}
            />

            {/* 内容 */}
            <div className="relative flex items-center gap-4">
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              >
                <Star className="w-5 h-5 sm:w-6 sm:h-6" fill="rgba(235, 235, 240, 0.2)" />
              </motion.div>
              
              <span className="text-base sm:text-lg font-medium tracking-wide">
                应用推荐界限阈值
              </span>
              
              {selectedGames.length > 0 && (
                <motion.div
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="px-3 py-1.5 bg-[rgba(57,255,20,0.2)] rounded-lg border border-[rgba(57,255,20,0.4)]"
                  style={{
                    boxShadow: '0 0 20px rgba(57, 255, 20, 0.3)'
                  }}
                >
                  <span className="text-sm font-bold" style={{ color: '#39ff14' }}>
                    {selectedGames.length}
                  </span>
                </motion.div>
              )}
              
              <motion.div 
                className="w-2.5 h-2.5 rounded-full relative"
                style={{ backgroundColor: '#39ff14' }}
                animate={{ 
                  opacity: [0.4, 1, 0.4],
                  scale: [1, 1.2, 1]
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <motion.div
                  className="absolute inset-0 rounded-full"
                  style={{ backgroundColor: '#39ff14' }}
                  animate={{ 
                    scale: [1, 2, 1],
                    opacity: [0.6, 0, 0.6]
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              </motion.div>
            </div>
          </motion.button>
        </div>
      </div>
    </PremiumBackground>
  );
}

export default App;