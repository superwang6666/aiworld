import svgPaths from "./svg-49mfnl1mym";
import imgImage4 from "figma:asset/6d33943b11519da5e5743b0fd148ab0048eddbd4.png";
import imgImage1 from "figma:asset/e7541c0986158cf155c95223342c7a1b1b8d0c00.png";
import imgImage3 from "figma:asset/3ae97393c9fd2877f01f9267a95465fb43ccc638.png";

function Container() {
  return <div className="absolute h-[944px] left-0 top-0 w-[1549px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 1549 944\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -94.4 -154.9 0 774.5 0)\'><stop stop-color=\'rgba(50,40,80,0.15)\' offset=\'0\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.5\'/></radialGradient></defs></svg>'), url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 1549 944\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -75.52 -123.92 0 0 472)\'><stop stop-color=\'rgba(40,60,80,0.1)\' offset=\'0\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.5\'/></radialGradient></defs></svg>'), url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 1549 944\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -75.52 -123.92 0 1549 472)\'><stop stop-color=\'rgba(60,40,70,0.1)\' offset=\'0\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.5\'/></radialGradient></defs></svg>'), linear-gradient(rgb(15, 15, 20) 0%, rgb(26, 26, 36) 100%)" }} />;
}

function Container1() {
  return <div className="absolute blur-[80px] left-[109.57px] opacity-43 size-[837.462px] top-[154.11px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 837.46 837.46\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -59.218 -59.218 0 418.73 418.73)\'><stop stop-color=\'rgba(120,80,180,0.25)\' offset=\'0\'/><stop stop-color=\'rgba(100,70,150,0.15)\' offset=\'0.25\'/><stop stop-color=\'rgba(80,60,120,0.08)\' offset=\'0.5\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container2() {
  return <div className="absolute blur-[90px] left-[471.81px] opacity-71 size-[901.636px] top-[155.95px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 901.64 901.64\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -63.755 -63.755 0 450.82 450.82)\'><stop stop-color=\'rgba(80,120,180,0.25)\' offset=\'0\'/><stop stop-color=\'rgba(60,100,150,0.15)\' offset=\'0.25\'/><stop stop-color=\'rgba(50,80,120,0.08)\' offset=\'0.5\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container3() {
  return <div className="absolute blur-[100px] h-[743.239px] left-[253.46px] opacity-69 top-[177.99px] w-[1114.858px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 1114.9 743.24\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -52.555 -78.832 0 557.43 371.62)\'><stop stop-color=\'rgba(60,140,160,0.2)\' offset=\'0\'/><stop stop-color=\'rgba(50,110,130,0.12)\' offset=\'0.3\'/><stop stop-color=\'rgba(40,80,100,0.06)\' offset=\'0.6\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.8\'/></radialGradient></defs></svg>')" }} />;
}

function Container4() {
  return <div className="absolute h-[944px] left-0 opacity-31 top-0 w-[1549px]" data-name="Container" style={{ backgroundImage: "linear-gradient(rgba(100, 120, 180, 0.03) 0.10593%, rgba(0, 0, 0, 0) 0.10593%), linear-gradient(90deg, rgba(100, 120, 180, 0.03) 0%, rgba(0, 0, 0, 0) 0%)" }} />;
}

function Container5() {
  return <div className="absolute bg-gradient-to-r from-[rgba(0,0,0,0)] h-[944px] left-[-1378.82px] to-[rgba(0,0,0,0)] top-0 via-1/2 via-[rgba(120,100,180,0.1)] w-[3098px]" data-name="Container" />;
}

function Container6() {
  return <div className="absolute blur-[1px] h-[3.548px] left-[1100.79px] opacity-23 rounded-[33554400px] shadow-[0px_0px_5.055px_0px_rgba(170,211,255,0.6)] top-[711.35px] w-[3.43px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 3.4302 3.5475\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.24673 -0.24673 0 1.7151 1.7738)\'><stop stop-color=\'rgba(249,186,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(187,140,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(125,93,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(62,47,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container7() {
  return <div className="absolute blur-[1px] h-[3.499px] left-[890.89px] opacity-39 rounded-[33554400px] shadow-[0px_0px_6.8px_0px_rgba(157,242,255,0.6)] top-[730.76px] w-[2.225px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 2.2252 3.499\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.20733 -0.20733 0 1.1126 1.7495)\'><stop stop-color=\'rgba(203,232,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(152,174,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(102,116,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(51,58,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container8() {
  return <div className="absolute blur-[1px] h-[2.529px] left-[651.29px] opacity-42 rounded-[33554400px] shadow-[0px_0px_4.795px_0px_rgba(155,239,255,0.6)] top-[815.52px] w-[3.71px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 3.7099 2.5287\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.22449 -0.22449 0 1.8549 1.2643)\'><stop stop-color=\'rgba(206,218,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(155,164,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(103,109,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(52,55,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container9() {
  return <div className="absolute blur-[1px] h-[4.901px] left-[599.91px] opacity-60 rounded-[33554400px] shadow-[0px_0px_7.643px_0px_rgba(177,253,255,0.6)] top-[377.39px] w-[5.029px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 5.0291 4.9015\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.35113 -0.35113 0 2.5145 2.4507)\'><stop stop-color=\'rgba(178,176,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(134,132,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(89,88,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(45,44,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container10() {
  return <div className="absolute blur-[1px] h-[3.861px] left-[1249.93px] opacity-20 rounded-[33554400px] shadow-[0px_0px_7.31px_0px_rgba(248,238,255,0.6)] top-[866.59px] w-[2.616px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 2.6156 3.8605\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.23316 -0.23316 0 1.3078 1.9303)\'><stop stop-color=\'rgba(178,162,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(134,122,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(89,81,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(45,41,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container11() {
  return <div className="absolute blur-[1px] h-[1.76px] left-[695.65px] opacity-25 rounded-[33554400px] shadow-[0px_0px_5.578px_0px_rgba(253,214,255,0.6)] top-[830.78px] w-[3.793px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 3.7932 1.7601\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.20908 -0.20908 0 1.8966 0.88007)\'><stop stop-color=\'rgba(222,154,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(167,116,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(111,77,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(56,39,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container12() {
  return <div className="absolute blur-[1px] h-[2.485px] left-[708.83px] opacity-27 rounded-[33554400px] shadow-[0px_0px_6.124px_0px_rgba(211,180,255,0.6)] top-[453.3px] w-[3.24px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 3.2395 2.4855\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.20416 -0.20416 0 1.6198 1.2427)\'><stop stop-color=\'rgba(191,251,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(143,188,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(96,126,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(48,63,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container13() {
  return <div className="absolute blur-[1px] h-[3.081px] left-[994.47px] opacity-64 rounded-[33554400px] shadow-[0px_0px_9.594px_0px_rgba(186,221,255,0.6)] top-[565.4px] w-[4.852px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 4.8522 3.0811\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.28739 -0.28739 0 2.4261 1.5405)\'><stop stop-color=\'rgba(179,216,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(134,162,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(90,108,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(45,54,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container14() {
  return <div className="absolute blur-[1px] h-[3.886px] left-[1232.92px] opacity-23 rounded-[33554400px] shadow-[0px_0px_5.244px_0px_rgba(246,236,255,0.6)] top-[223.7px] w-[2.586px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 2.5864 3.8863\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.23341 -0.23341 0 1.2932 1.9431)\'><stop stop-color=\'rgba(236,164,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(177,123,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(118,82,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(59,41,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container15() {
  return <div className="absolute blur-[1px] h-[3.143px] left-[1297.8px] opacity-52 rounded-[33554400px] shadow-[0px_0px_8.435px_0px_rgba(226,246,255,0.6)] top-[274.73px] w-[5.068px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 5.0682 3.1434\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.29819 -0.29819 0 2.5341 1.5717)\'><stop stop-color=\'rgba(242,188,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(182,141,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(121,94,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(61,47,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container16() {
  return <div className="absolute blur-[1px] h-[3.508px] left-[487.06px] opacity-52 rounded-[33554400px] shadow-[0px_0px_9.908px_0px_rgba(214,154,255,0.6)] top-[799.53px] w-[5.121px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 5.121 3.5085\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.31038 -0.31038 0 2.5605 1.7542)\'><stop stop-color=\'rgba(189,198,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(142,149,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(95,99,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(47,50,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container17() {
  return <div className="absolute blur-[1px] h-[3.265px] left-[1292.35px] opacity-53 rounded-[33554400px] shadow-[0px_0px_9.611px_0px_rgba(198,213,255,0.6)] top-[18.34px] w-[3.283px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 3.2827 3.2649\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.23149 -0.23149 0 1.6414 1.6325)\'><stop stop-color=\'rgba(152,248,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(114,186,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(76,124,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(38,62,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container18() {
  return <div className="absolute blur-[1px] h-[3.135px] left-[80.01px] opacity-60 rounded-[33554400px] shadow-[0px_0px_7.892px_0px_rgba(220,254,255,0.6)] top-[728.74px] w-[5.341px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 5.3412 3.1354\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.30967 -0.30967 0 2.6706 1.5677)\'><stop stop-color=\'rgba(213,190,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(160,143,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(107,95,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(53,48,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container19() {
  return <div className="absolute blur-[1px] h-[3.438px] left-[868.61px] opacity-55 rounded-[33554400px] shadow-[0px_0px_5.264px_0px_rgba(170,248,255,0.6)] top-[540.44px] w-[5.372px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 5.3716 3.4379\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.31888 -0.31888 0 2.6858 1.7189)\'><stop stop-color=\'rgba(246,200,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(185,150,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(123,100,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(62,50,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container20() {
  return <div className="absolute blur-[1px] h-[4.486px] left-[674.62px] opacity-65 rounded-[33554400px] shadow-[0px_0px_5.09px_0px_rgba(192,249,255,0.6)] top-[395.11px] w-[3.785px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 3.7847 4.4863\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.29348 -0.29348 0 1.8924 2.2431)\'><stop stop-color=\'rgba(232,231,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(174,173,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(116,116,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(58,58,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container21() {
  return <div className="absolute blur-[1px] h-[3.494px] left-[1515.29px] opacity-20 rounded-[33554400px] shadow-[0px_0px_6.606px_0px_rgba(158,223,255,0.6)] top-[663.09px] w-[1.691px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 1.6908 3.4944\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.1941 -0.1941 0 0.8454 1.7472)\'><stop stop-color=\'rgba(186,231,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(140,173,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(93,116,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(47,58,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container22() {
  return <div className="absolute blur-[1px] h-[4.406px] left-[3.63px] opacity-72 rounded-[33554400px] shadow-[0px_0px_4.713px_0px_rgba(172,184,255,0.6)] top-[388.63px] w-[2.95px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 2.9499 4.4062\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.26513 -0.26513 0 1.475 2.2031)\'><stop stop-color=\'rgba(197,226,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(148,170,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(99,113,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(49,57,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container23() {
  return <div className="absolute blur-[1px] h-[3.773px] left-[196.8px] opacity-40 rounded-[33554400px] shadow-[0px_0px_4.818px_0px_rgba(236,218,255,0.6)] top-[248.32px] w-[2.911px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 2.9113 3.7733\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.23829 -0.23829 0 1.4556 1.8866)\'><stop stop-color=\'rgba(189,176,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(142,132,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(95,88,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(47,44,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container24() {
  return <div className="absolute blur-[1px] h-[5.484px] left-[650.64px] opacity-63 rounded-[33554400px] shadow-[0px_0px_7.02px_0px_rgba(242,161,255,0.6)] top-[501.96px] w-[4.545px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 4.5452 5.4837\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.35613 -0.35613 0 2.2726 2.7419)\'><stop stop-color=\'rgba(231,167,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(173,125,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(116,84,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(58,42,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container25() {
  return <div className="absolute blur-[1px] h-[4.776px] left-[700.43px] opacity-68 rounded-[33554400px] shadow-[0px_0px_9.357px_0px_rgba(211,231,255,0.6)] top-[821.09px] w-[3.066px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 3.066 4.7756\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -0.28375 -0.28375 0 1.533 2.3878)\'><stop stop-color=\'rgba(185,216,255,0.8)\' offset=\'0\'/><stop stop-color=\'rgba(139,162,191,0.6)\' offset=\'0.175\'/><stop stop-color=\'rgba(93,108,128,0.4)\' offset=\'0.35\'/><stop stop-color=\'rgba(46,54,64,0.2)\' offset=\'0.525\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container26() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[600.23px] opacity-47 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[556px]" data-name="Container" />;
}

function Container27() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[1018.06px] opacity-22 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[450.31px]" data-name="Container" />;
}

function Container28() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[832.66px] opacity-31 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[621.91px]" data-name="Container" />;
}

function Container29() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[1137.66px] opacity-26 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[0.86px]" data-name="Container" />;
}

function Container30() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[130.81px] opacity-47 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[543.52px]" data-name="Container" />;
}

function Container31() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[1276.73px] opacity-38 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[261.86px]" data-name="Container" />;
}

function Container32() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[956.73px] opacity-20 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[898.58px]" data-name="Container" />;
}

function Container33() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[543.08px] opacity-45 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[478.61px]" data-name="Container" />;
}

function Container34() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[1021.3px] opacity-55 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[688.73px]" data-name="Container" />;
}

function Container35() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[1065.64px] opacity-20 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[558.17px]" data-name="Container" />;
}

function Container36() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[1267.75px] opacity-21 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[191.14px]" data-name="Container" />;
}

function Container37() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[338.86px] opacity-37 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[302.8px]" data-name="Container" />;
}

function Container38() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[1052.42px] opacity-27 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[561.45px]" data-name="Container" />;
}

function Container39() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[494.86px] opacity-33 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[369.91px]" data-name="Container" />;
}

function Container40() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[571.64px] opacity-22 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[526.59px]" data-name="Container" />;
}

function Container41() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[175.52px] opacity-46 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[370.02px]" data-name="Container" />;
}

function Container42() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[760.06px] opacity-40 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[621.5px]" data-name="Container" />;
}

function Container43() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[331.81px] opacity-20 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[458.58px]" data-name="Container" />;
}

function Container44() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[1046.38px] opacity-34 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[785.88px]" data-name="Container" />;
}

function Container45() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[8.53px] opacity-31 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[605.97px]" data-name="Container" />;
}

function Container46() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[277.83px] opacity-24 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[169.53px]" data-name="Container" />;
}

function Container47() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[488.83px] opacity-41 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[899.84px]" data-name="Container" />;
}

function Container48() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[635.34px] opacity-21 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[635.64px]" data-name="Container" />;
}

function Container49() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[23.22px] opacity-59 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[704.39px]" data-name="Container" />;
}

function Container50() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[904.36px] opacity-59 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[579.38px]" data-name="Container" />;
}

function Container51() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[659.53px] opacity-20 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[497.23px]" data-name="Container" />;
}

function Container52() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[66.92px] opacity-25 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[596.92px]" data-name="Container" />;
}

function Container53() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[1325.97px] opacity-20 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[185.09px]" data-name="Container" />;
}

function Container54() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[918.69px] opacity-49 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[551.77px]" data-name="Container" />;
}

function Container55() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[647.98px] opacity-35 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[550.08px]" data-name="Container" />;
}

function Container56() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[588.78px] opacity-43 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[932.66px]" data-name="Container" />;
}

function Container57() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[80.06px] opacity-25 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[323.25px]" data-name="Container" />;
}

function Container58() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[253.83px] opacity-20 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[535.75px]" data-name="Container" />;
}

function Container59() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[200.02px] opacity-22 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[324.28px]" data-name="Container" />;
}

function Container60() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[1184.48px] opacity-20 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[231.38px]" data-name="Container" />;
}

function Container61() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[1464.98px] opacity-32 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[262.44px]" data-name="Container" />;
}

function Container62() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[1035.94px] opacity-45 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[52.03px]" data-name="Container" />;
}

function Container63() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[67.77px] opacity-23 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[411.19px]" data-name="Container" />;
}

function Container64() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[431.3px] opacity-55 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[624.05px]" data-name="Container" />;
}

function Container65() {
  return <div className="absolute bg-[rgba(255,255,255,0.4)] left-[134.56px] opacity-35 rounded-[33554400px] shadow-[0px_0px_2px_0px_rgba(255,255,255,0.5)] size-px top-[239.31px]" data-name="Container" />;
}

function Container66() {
  return <div className="absolute blur-[30px] left-[660.64px] rounded-[33554400px] size-[68.567px] top-[731.39px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 68.567 68.567\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -4.8484 -4.8484 0 34.283 34.283)\'><stop stop-color=\'rgba(106,158,202,0.15)\' offset=\'0\'/><stop stop-color=\'rgba(53,79,101,0.075)\' offset=\'0.35\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container67() {
  return <div className="absolute blur-[30px] left-[302.34px] rounded-[33554400px] size-[71.352px] top-[613.51px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 71.352 71.352\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -5.0454 -5.0454 0 35.676 35.676)\'><stop stop-color=\'rgba(163,129,235,0.15)\' offset=\'0\'/><stop stop-color=\'rgba(82,65,118,0.075)\' offset=\'0.35\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container68() {
  return <div className="absolute blur-[30px] left-[1198.78px] rounded-[33554400px] size-[89.032px] top-[743.35px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 89.032 89.032\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -6.2955 -6.2955 0 44.516 44.516)\'><stop stop-color=\'rgba(117,174,182,0.15)\' offset=\'0\'/><stop stop-color=\'rgba(59,87,91,0.075)\' offset=\'0.35\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container69() {
  return <div className="absolute blur-[30px] left-[583.92px] rounded-[33554400px] size-[67.522px] top-[334.88px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 67.522 67.522\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -4.7745 -4.7745 0 33.761 33.761)\'><stop stop-color=\'rgba(161,118,240,0.15)\' offset=\'0\'/><stop stop-color=\'rgba(81,59,120,0.075)\' offset=\'0.35\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container70() {
  return <div className="absolute blur-[30px] left-[399.06px] rounded-[33554400px] size-[89.37px] top-[193.21px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 89.37 89.37\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -6.3194 -6.3194 0 44.685 44.685)\'><stop stop-color=\'rgba(159,138,212,0.15)\' offset=\'0\'/><stop stop-color=\'rgba(80,69,106,0.075)\' offset=\'0.35\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container71() {
  return <div className="absolute blur-[30px] left-[1183.89px] rounded-[33554400px] size-[78.776px] top-[279.38px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 78.776 78.776\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -5.5703 -5.5703 0 39.388 39.388)\'><stop stop-color=\'rgba(107,103,187,0.15)\' offset=\'0\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container72() {
  return <div className="absolute blur-[30px] left-[433.52px] rounded-[33554400px] size-[89.851px] top-[418.19px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 89.851 89.851\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -6.3534 -6.3534 0 44.926 44.925)\'><stop stop-color=\'rgba(105,127,248,0.15)\' offset=\'0\'/><stop stop-color=\'rgba(53,64,124,0.075)\' offset=\'0.35\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container73() {
  return <div className="absolute blur-[30px] left-[1105.49px] rounded-[33554400px] size-[86.825px] top-[683.8px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 86.825 86.825\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -6.1395 -6.1395 0 43.412 43.412)\'><stop stop-color=\'rgba(128,127,223,0.15)\' offset=\'0\'/><stop stop-color=\'rgba(64,64,112,0.075)\' offset=\'0.35\'/><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0.7\'/></radialGradient></defs></svg>')" }} />;
}

function Container74() {
  return <div className="absolute h-[944px] left-0 opacity-4 top-0 w-[1549px]" data-name="Container" />;
}

function Container75() {
  return <div className="absolute h-[944px] left-0 top-0 w-[1549px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\'0 0 1549 944\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'><rect x=\'0\' y=\'0\' height=\'100%\' width=\'100%\' fill=\'url(%23grad)\' opacity=\'1\'/><defs><radialGradient id=\'grad\' gradientUnits=\'userSpaceOnUse\' cx=\'0\' cy=\'0\' r=\'10\' gradientTransform=\'matrix(0 -66.08 -108.43 0 774.5 377.6)\'><stop stop-color=\'rgba(0,0,0,0)\' offset=\'0\'/><stop stop-color=\'rgba(15,15,20,0.5)\' offset=\'0.8\'/><stop stop-color=\'rgba(15,15,20,0.8)\' offset=\'1\'/></radialGradient></defs></svg>')" }} />;
}

function Paragraph() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute css-ew64yg font-['Arial:Bold',sans-serif] leading-[24px] left-0 not-italic text-[13px] text-white top-[-1px]">WORLD</p>
    </div>
  );
}

function Container76() {
  return (
    <div className="bg-gradient-to-b flex-[1_0_0] from-[#8a8a95] h-[40px] min-h-px min-w-px relative rounded-[18px] to-[#6a6a75]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[8px] px-[16px] relative size-full">
        <Paragraph />
      </div>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[18px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute css-ew64yg font-['Arial:Regular',sans-serif] leading-[18px] left-0 not-italic text-[#c1c5cc] text-[12px] top-[-1px]">BETA</p>
    </div>
  );
}

function Container77() {
  return (
    <div className="bg-[#2a2a35] h-[26px] relative rounded-[18px] shrink-0 w-[52.5px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[4px] px-[12px] relative size-full">
        <Paragraph1 />
      </div>
    </div>
  );
}

function Container78() {
  return (
    <div className="h-[40px] relative shrink-0 w-[143.609px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Container76 />
        <Container77 />
      </div>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="h-[21px] relative shrink-0 w-[56px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['Arial:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] leading-[21px] left-0 text-[#c1c5cc] text-[14px] top-[-1px]" style={{ fontVariationSettings: "'wght' 400" }}>
          简体中文
        </p>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p27e361f0} fill="var(--fill-0, #9A9AAA)" id="Vector" />
          <path d={svgPaths.p391be280} fill="var(--fill-0, #9A9AAA)" id="Vector_2" />
          <path d={svgPaths.pe903a80} id="Vector_3" stroke="var(--stroke-0, #9A9AAA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.pd384680} id="Vector_4" stroke="var(--stroke-0, #9A9AAA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] relative rounded-[12px] shrink-0 size-[36px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-px relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p18e22200} fill="var(--fill-0, #9A9AAA)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[rgba(60,60,70,0.6)] relative rounded-[12px] shrink-0 size-[36px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(100,100,110,0.3)] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-px relative size-full">
        <Icon1 />
      </div>
    </div>
  );
}

function Container79() {
  return (
    <div className="h-[37px] relative shrink-0 w-[382px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center relative size-full">
        <Paragraph2 />
        <Button />
        <Button1 />
        <div className="h-[49px] relative shrink-0 w-[182px]" data-name="image 4">
          <div className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 overflow-hidden pointer-events-none">
            <img alt="" className="absolute h-[1859.18%] left-[-913.19%] max-w-none top-[-104.08%] w-[1054.94%]" src={imgImage4} />
          </div>
        </div>
      </div>
    </div>
  );
}

function Container80() {
  return (
    <div className="absolute content-stretch flex h-[88px] items-center justify-between left-0 px-[64px] top-0 w-[1549px]" data-name="Container">
      <Container78 />
      <Container79 />
    </div>
  );
}

function Component1() {
  return (
    <div className="absolute h-[944px] left-0 overflow-clip top-0 w-[1549px]" data-name="Component2">
      <Container80 />
      <div className="absolute h-[741px] left-[131px] top-[88px] w-[1315px]" data-name="image 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
      </div>
      <div className="absolute h-[94px] left-[210px] top-[850px] w-[1145px]" data-name="image 3">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[915.96%] left-0 max-w-none top-[-815.96%] w-full" src={imgImage3} />
        </div>
      </div>
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-[#0f0f14] relative size-full" data-name="推荐游戏">
      <Container />
      <Container1 />
      <Container2 />
      <Container3 />
      <Container4 />
      <Container5 />
      <Container6 />
      <Container7 />
      <Container8 />
      <Container9 />
      <Container10 />
      <Container11 />
      <Container12 />
      <Container13 />
      <Container14 />
      <Container15 />
      <Container16 />
      <Container17 />
      <Container18 />
      <Container19 />
      <Container20 />
      <Container21 />
      <Container22 />
      <Container23 />
      <Container24 />
      <Container25 />
      <Container26 />
      <Container27 />
      <Container28 />
      <Container29 />
      <Container30 />
      <Container31 />
      <Container32 />
      <Container33 />
      <Container34 />
      <Container35 />
      <Container36 />
      <Container37 />
      <Container38 />
      <Container39 />
      <Container40 />
      <Container41 />
      <Container42 />
      <Container43 />
      <Container44 />
      <Container45 />
      <Container46 />
      <Container47 />
      <Container48 />
      <Container49 />
      <Container50 />
      <Container51 />
      <Container52 />
      <Container53 />
      <Container54 />
      <Container55 />
      <Container56 />
      <Container57 />
      <Container58 />
      <Container59 />
      <Container60 />
      <Container61 />
      <Container62 />
      <Container63 />
      <Container64 />
      <Container65 />
      <Container66 />
      <Container67 />
      <Container68 />
      <Container69 />
      <Container70 />
      <Container71 />
      <Container72 />
      <Container73 />
      <Container74 />
      <Container75 />
      <Component1 />
    </div>
  );
}